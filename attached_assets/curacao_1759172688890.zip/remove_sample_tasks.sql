-- Manual script to remove sample tasks
-- Run this in your Supabase SQL editor or database client

-- Remove all sample tasks
DELETE FROM tasks WHERE title IN (
  'Morning Yoga',
  'Team Walk', 
  'Stair Challenge',
  'Desk Exercises',
  'Lunch Break Workout',
  'Active Commute',
  'Weekend Adventure'
);

-- Verify tasks are removed
SELECT COUNT(*) as remaining_tasks FROM tasks;

-- Show remaining tasks (should be 0 after running the delete)
SELECT * FROM tasks;
