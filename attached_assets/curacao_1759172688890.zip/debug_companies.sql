-- Debug script to check companies in the database
-- Run this in Supabase SQL editor to see all companies

-- Check all companies
SELECT 
  id,
  name,
  contact_name,
  contact_last_name,
  email,
  phone,
  total_points,
  total_calories,
  created_at
FROM companies 
ORDER BY created_at DESC;

-- Check if there are any companies at all
SELECT COUNT(*) as total_companies FROM companies;

-- Check recent auth users
SELECT 
  id,
  email,
  created_at,
  email_confirmed_at,
  raw_user_meta_data
FROM auth.users 
ORDER BY created_at DESC 
LIMIT 10;
