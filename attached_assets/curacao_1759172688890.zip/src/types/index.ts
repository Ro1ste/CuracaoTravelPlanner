export interface Company {
  id: string;
  name: string;
  contact_name: string;
  contact_last_name: string;
  email: string;
  phone: string;
  created_at: string;
  total_points: number;
  total_calories: number;
  logo_url?: string;
  participant_count?: number;
}

export interface User {
  id: string;
  company_id: string;
  email: string;
  created_at: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  document_url?: string;
  day: number;
  target_calories: number;
  created_at: string;
}

export interface Upload {
  id: string;
  company_id: string;
  task_id: string;
  file_url: string;
  file_type: 'image' | 'video';
  status: 'pending' | 'approved' | 'rejected';
  points_awarded?: number;
  created_at: string;
}

export interface DailyCalories {
  id: string;
  day: number;
  target_calories: number;
  date: string;
  created_at: string;
}