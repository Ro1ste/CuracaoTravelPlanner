import React, { createContext, useContext, useEffect, useState } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import { Company } from '../types';

interface AuthContextType {
  user: User | null;
  company: Company | null;
  loading: boolean;
  isAdmin: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  refreshCompany: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [company, setCompany] = useState<Company | null>(null);
  const [loading, setLoading] = useState(true);
  const adminEmails = (import.meta.env.VITE_ADMIN_EMAILS || '')
    .split(',')
    .map((e: string) => e.trim().toLowerCase())
    .filter(Boolean);
  const isAdmin = !!(user?.email && adminEmails.includes(user.email.toLowerCase()));

  const fetchCompany = async (userId: string) => {
    const { data, error } = await supabase
      .from('companies')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (error) throw error;
    return data;
  };

  const refreshCompany = async () => {
    if (user) {
      try {
        const companyData = await fetchCompany(user.id);
        setCompany(companyData);
      } catch (error) {
        console.error('Error fetching company:', error);
      }
    }
  };

  useEffect(() => {
    const initAuth = async () => {
      // Safety timeout so UI never blocks indefinitely
      const safetyTimeout = setTimeout(() => setLoading(false), 2000);
      try {
        const { data: { session } } = await supabase.auth.getSession();
        
        if (session?.user) {
          setUser(session.user);
          // End loading immediately; fetch company in background
          setLoading(false);
          fetchCompany(session.user.id)
            .then(setCompany)
            .catch((error) => console.error('Error fetching company:', error));
        } else {
          setLoading(false);
        }
      } catch (error) {
        console.error('Error initializing auth:', error);
        setLoading(false);
      } finally {
        clearTimeout(safetyTimeout);
      }
    };

    initAuth();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        setUser(session?.user ?? null);
        // End loading immediately on any auth change
        setLoading(false);
        
        if (session?.user) {
          fetchCompany(session.user.id)
            .then(setCompany)
            .catch((error) => console.error('Error fetching company:', error));
        } else {
          setCompany(null);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  // Real-time subscription disabled to avoid WebSocket errors
  // useEffect(() => {
  //   if (!user) return;

  //   const channel = supabase
  //     .channel('company-updates')
  //     .on(
  //       'postgres_changes',
  //       {
  //         event: 'UPDATE',
  //         schema: 'public',
  //         table: 'companies',
  //         filter: `id=eq.${user.id}`,
  //       },
  //       (payload) => {
  //         console.log('Company data updated:', payload);
  //         setCompany(payload.new as Company);
  //       }
  //     )
  //     .subscribe();

  //   return () => {
  //     supabase.removeChannel(channel);
  //   };
  // }, [user]);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    if (error) throw error;
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  };

  return (
    <AuthContext.Provider value={{
      user,
      company,
      loading,
      isAdmin,
      signIn,
      signOut,
      refreshCompany,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}