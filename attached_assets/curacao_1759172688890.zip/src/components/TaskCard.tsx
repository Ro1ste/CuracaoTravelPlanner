import React from 'react';
import { Task, Upload } from '../types';
import { motion } from 'framer-motion';
import { 
  Calendar, 
  Target, 
  Upload as UploadIcon, 
  CheckCircle, 
  Clock, 
  XCircle,
  FileText
} from 'lucide-react';

interface TaskCardProps {
  task: Task;
  upload?: Upload;
  onUpload: (task: Task) => void;
}

export function TaskCard({ task, upload, onUpload }: TaskCardProps) {
  const getStatusIcon = () => {
    if (!upload) return <Clock className="w-4 h-4 text-gray-500" />;
    
    switch (upload.status) {
      case 'approved':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'rejected':
        return <XCircle className="w-4 h-4 text-red-600" />;
      default:
        return <Clock className="w-4 h-4 text-yellow-600" />;
    }
  };

  const getStatusText = () => {
    if (!upload) return 'Not submitted';
    
    switch (upload.status) {
      case 'approved':
        return `Approved (+${upload.points_awarded || 0} points)`;
      case 'rejected':
        return 'Rejected';
      default:
        return 'Pending review';
    }
  };

  const getStatusColor = () => {
    if (!upload) return 'text-gray-600';
    
    switch (upload.status) {
      case 'approved':
        return 'text-green-600';
      case 'rejected':
        return 'text-red-600';
      default:
        return 'text-yellow-600';
    }
  };

  return (
    <motion.div 
      className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6 hover:shadow-xl transition-all duration-300"
      whileHover={{ y: -4 }}
      layout
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-br from-sky-500 to-blue-600 rounded-lg flex items-center justify-center">
            <Calendar className="w-4 h-4 text-white" />
          </div>
          <span className="font-semibold text-sky-600">Day {task.day}</span>
        </div>
        <div className="flex items-center space-x-1">
          {getStatusIcon()}
          <span className={`text-sm font-medium ${getStatusColor()}`}>
            {getStatusText()}
          </span>
        </div>
      </div>

      <h3 className="text-xl font-bold text-gray-900 mb-3">{task.title}</h3>
      <p className="text-gray-600 mb-4 line-clamp-3">{task.description}</p>

      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <Target className="w-4 h-4" />
          <span>{task.target_calories} calories target</span>
        </div>
        {task.document_url && (
          <a
            href={task.document_url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center space-x-1 text-sky-600 hover:text-sky-700 text-sm font-medium transition-colors duration-200"
          >
            <FileText className="w-4 h-4" />
            <span>View Document</span>
          </a>
        )}
      </div>

      <motion.button
        onClick={() => onUpload(task)}
        disabled={upload?.status === 'approved'}
        className={`w-full py-3 px-4 rounded-xl font-semibold flex items-center justify-center space-x-2 transition-all duration-200 ${
          upload?.status === 'approved'
            ? 'bg-green-100 text-green-800 cursor-not-allowed'
            : 'bg-gradient-to-r from-sky-500 to-blue-600 text-white hover:from-sky-600 hover:to-blue-700'
        }`}
        whileHover={upload?.status !== 'approved' ? { scale: 1.02 } : {}}
        whileTap={upload?.status !== 'approved' ? { scale: 0.98 } : {}}
      >
        <UploadIcon className="w-4 h-4" />
        <span>
          {upload?.status === 'approved' 
            ? 'Completed' 
            : upload 
            ? 'Resubmit' 
            : 'Upload Proof'
          }
        </span>
      </motion.button>
    </motion.div>
  );
}