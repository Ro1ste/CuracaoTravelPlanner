import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { signUp, signIn } from '../lib/supabase';
import toast from 'react-hot-toast';
import { motion } from 'framer-motion';
import { Building2, User, Mail, Phone, Lock } from 'lucide-react';

const schema = yup.object({
  companyName: yup.string().required('Company name is required'),
  contactName: yup.string().required('Contact name is required'),
  contactLastName: yup.string().required('Contact last name is required'),
  email: yup.string().email('Invalid email').required('Email is required'),
  phone: yup.string().required('Phone number is required'),
  password: yup.string().min(8, 'Password must be at least 8 characters').required('Password is required'),
  confirmPassword: yup
    .string()
    .oneOf([yup.ref('password')], 'Passwords must match')
    .required('Confirm your password'),
});

type FormData = yup.InferType<typeof schema>;

interface RegistrationFormProps {
  onSuccess: () => void;
  onSwitchToLogin: () => void;
}

export function RegistrationForm({ onSuccess, onSwitchToLogin }: RegistrationFormProps) {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormData>({
    resolver: yupResolver(schema),
  });

  const onSubmit = async (data: FormData) => {
    try {
      await signUp(data.email, data.password, {
        name: data.companyName,
        contact_name: data.contactName,
        contact_last_name: data.contactLastName,
        phone: data.phone,
      });

      // Try auto sign-in (will only work if email confirmations are disabled)
      try {
        await signIn(data.email, data.password);
      } catch (_err) {
        // Ignore if email confirmation is required
      }

      toast.success('Account created! Check your email for confirmation if required.');
      onSuccess();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Registration failed');
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: 'url(/curacao2.jpeg)'
        }}
      >
        {/* Subtle overlay to enhance the vibrant background */}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/10 via-blue-900/10 to-indigo-900/10"></div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <motion.div 
          className="bg-gradient-to-br from-white/30 via-purple-50/20 to-blue-50/20 backdrop-blur-md rounded-3xl shadow-2xl p-8 w-full max-w-md border border-white/20 max-h-[90vh] overflow-y-auto"
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.6 }}
        >
          <div className="text-center mb-8">
            <motion.img 
              src="/eisw.jpeg" 
              alt="eISW Logo" 
              className="w-32 h-32 object-contain rounded-lg mx-auto mb-6 shadow-xl"
              initial={{ scale: 0, rotate: -180 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ duration: 0.8, delay: 0.2, type: "spring" }}
            />
            <motion.h1 
              className="text-3xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 bg-clip-text text-transparent mb-2"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              Join Curaçao Sportsweek
            </motion.h1>
            <motion.p 
              className="text-white/80"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              Register your company to participate in the challenge
            </motion.p>
          </div>

        

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <label className="block text-sm font-semibold text-white mb-2">
              <Building2 className="w-4 h-4 inline mr-2" />
              Company Name
            </label>
            <input
              {...register('companyName')}
              className="w-full px-4 py-3 border border-white/30 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 bg-white/20 backdrop-blur-sm text-white placeholder-white/70"
              placeholder="Enter your company name"
            />
              {errors.companyName && (
                <p className="text-red-300 text-sm mt-1">{errors.companyName.message}</p>
              )}
          </motion.div>

          <div className="grid grid-cols-2 gap-4">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <label className="block text-sm font-semibold text-white mb-2">
                <User className="w-4 h-4 inline mr-2" />
                First Name
              </label>
              <input
                {...register('contactName')}
                className="w-full px-4 py-3 border border-white/30 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 bg-white/20 backdrop-blur-sm text-white placeholder-white/70"
                placeholder="First name"
              />
              {errors.contactName && (
                <p className="text-red-300 text-sm mt-1">{errors.contactName.message}</p>
              )}
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.5 }}
            >
              <label className="block text-sm font-semibold text-white mb-2">Last Name</label>
              <input
                {...register('contactLastName')}
                className="w-full px-4 py-3 border border-white/30 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 bg-white/20 backdrop-blur-sm text-white placeholder-white/70"
                placeholder="Last name"
              />
              {errors.contactLastName && (
                <p className="text-red-300 text-sm mt-1">{errors.contactLastName.message}</p>
              )}
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.6 }}
          >
            <label className="block text-sm font-semibold text-white mb-2">
              <Mail className="w-4 h-4 inline mr-2" />
              Email Address
            </label>
            <input
              {...register('email')}
              type="email"
              className="w-full px-4 py-3 border border-white/30 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 bg-white/20 backdrop-blur-sm text-white placeholder-white/70"
              placeholder="Enter your email"
            />
              {errors.email && (
                <p className="text-red-300 text-sm mt-1">{errors.email.message}</p>
              )}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.7 }}
          >
            <label className="block text-sm font-semibold text-white mb-2">
              <Phone className="w-4 h-4 inline mr-2" />
              Phone Number
            </label>
            <input
              {...register('phone')}
              type="tel"
              className="w-full px-4 py-3 border border-white/30 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 bg-white/20 backdrop-blur-sm text-white placeholder-white/70"
              placeholder="Enter your phone number"
            />
              {errors.phone && (
                <p className="text-red-300 text-sm mt-1">{errors.phone.message}</p>
              )}
          </motion.div>

          <div className="grid grid-cols-2 gap-4">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.75 }}
            >
              <label className="block text-sm font-semibold text-white mb-2">
                <Lock className="w-4 h-4 inline mr-2" />
                Password
              </label>
              <input
                {...register('password')}
                type="password"
                className="w-full px-4 py-3 border border-white/30 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 bg-white/20 backdrop-blur-sm text-white placeholder-white/70"
                placeholder="Create a password"
              />
              {errors.password && (
                <p className="text-red-300 text-sm mt-1">{errors.password.message}</p>
              )}
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.8 }}
            >
              <label className="block text-sm font-semibold text-white mb-2">
                <Lock className="w-4 h-4 inline mr-2" />
                Confirm Password
              </label>
              <input
                {...register('confirmPassword')}
                type="password"
                className="w-full px-4 py-3 border border-white/30 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all duration-200 bg-white/20 backdrop-blur-sm text-white placeholder-white/70"
                placeholder="Re-enter your password"
              />
              {errors.confirmPassword && (
                <p className="text-red-300 text-sm mt-1">{errors.confirmPassword.message}</p>
              )}
            </motion.div>
          </div>

          <motion.button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500 text-white py-3 px-6 rounded-xl font-semibold hover:from-purple-600 hover:via-pink-600 hover:to-blue-600 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-lg hover:shadow-xl"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.8 }}
          >
            {isSubmitting ? 'Creating Account...' : 'Register Company'}
          </motion.button>
        </form>

        <motion.div 
          className="text-center mt-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 1 }}
        >
          <p className="text-sm text-white/80 mb-4">
            Your account will be created with the details provided. Check your email if confirmation is required.
          </p>
          <p className="text-sm text-white/80">
            Already have an account?{' '}
            <button
              onClick={onSwitchToLogin}
              className="text-purple-300 hover:text-purple-200 font-medium transition-colors duration-200"
            >
              Sign in here
            </button>
          </p>
        </motion.div>
      </motion.div>
      </div>
    </div>
  );
}