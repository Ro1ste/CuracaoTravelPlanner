import { useState, useRef, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { motion } from 'framer-motion';
import { Trophy, Users, Flame, Edit, Award, Upload, Camera, Save, X } from 'lucide-react';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';

export function CompanyProfile() {
  const { company, refreshCompany } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [participants, setParticipants] = useState(company?.participant_count || 0);
  const [logoUrl, setLogoUrl] = useState<string | null>(company?.logo_url || null);
  const [uploadingLogo, setUploadingLogo] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Update state when company data changes
  useEffect(() => {
    if (company) {
      setParticipants(company.participant_count || 0);
      setLogoUrl(company.logo_url || null);
    }
  }, [company]);

  const handleLogoUpload = async (file: File) => {
    if (!company) return;
    
    setUploadingLogo(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `company-logos/${company.id}/logo.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from('company-logos')
        .upload(fileName, file, { upsert: true });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('company-logos')
        .getPublicUrl(fileName);

      setLogoUrl(publicUrl);
      toast.success('Logo uploaded successfully!');
    } catch (error) {
      toast.error('Failed to upload logo');
    } finally {
      setUploadingLogo(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleLogoUpload(file);
    }
  };

  const handleSaveProfile = async () => {
    if (!company) return;
    
    try {
      const { error } = await supabase
        .from('companies')
        .update({ 
          participant_count: participants,
          logo_url: logoUrl
        })
        .eq('id', company.id);

      if (error) throw error;
      
      toast.success('Profile updated successfully!');
      setIsEditing(false);
      refreshCompany();
    } catch (error) {
      console.error('Error updating profile:', error);
      toast.error('Failed to update profile');
    }
  };

  if (!company) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <motion.div
        className="flex items-center justify-end"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex space-x-2">
          {isEditing ? (
            <>
              <button 
                onClick={handleSaveProfile}
                className="px-4 py-2 bg-green-500 text-white rounded-lg text-sm font-medium hover:bg-green-600 transition-colors flex items-center space-x-2"
              >
                <Save className="w-4 h-4" />
                <span>Save</span>
              </button>
              <button 
                onClick={() => setIsEditing(false)}
                className="px-4 py-2 bg-gray-500 text-white rounded-lg text-sm font-medium hover:bg-gray-600 transition-colors flex items-center space-x-2"
              >
                <X className="w-4 h-4" />
                <span>Cancel</span>
              </button>
            </>
          ) : (
            <button 
              onClick={() => setIsEditing(true)}
              className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors flex items-center space-x-2"
            >
              <Edit className="w-4 h-4" />
              <span>Edit Profile</span>
            </button>
          )}
        </div>
      </motion.div>

      {/* Company Overview Card */}
      <motion.div
        className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-6 border border-blue-100"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <div className="relative">
              {logoUrl ? (
                <img 
                  src={logoUrl} 
                  alt="Company Logo" 
                  className="w-16 h-16 rounded-xl object-cover border-2 border-white shadow-lg"
                />
              ) : (
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
                  <span className="text-white font-bold text-lg">{company.name.charAt(0)}</span>
                </div>
              )}
              {isEditing && (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploadingLogo}
                  className="absolute -bottom-1 -right-1 w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors disabled:opacity-50"
                >
                  {uploadingLogo ? (
                    <div className="w-3 h-3 border border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Camera className="w-3 h-3" />
                  )}
                </button>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-gray-900">{company.name}</h2>
              <div className="flex items-center space-x-6 mt-2">
                <div className="flex items-center space-x-2">
                  <Users className="w-4 h-4 text-gray-600" />
                  {isEditing ? (
                    <input
                      type="number"
                      value={participants}
                      onChange={(e) => setParticipants(parseInt(e.target.value) || 0)}
                      className="w-20 px-2 py-1 border border-gray-300 rounded text-sm"
                      min="1"
                    />
                  ) : (
                    <span className="text-gray-600">{participants} Participants</span>
                  )}
                </div>
                <div className="flex items-center space-x-2">
                  <Trophy className="w-4 h-4 text-orange-500" />
                  <span className="text-orange-500 font-semibold">{company.total_points} Total Points</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Flame className="w-4 h-4 text-orange-500" />
                  <span className="text-orange-500 font-semibold">{company.total_calories} Calories Burned</span>
                </div>
              </div>
            </div>
          </div>
          <button className="px-3 py-1 bg-gray-100 text-gray-700 rounded text-sm font-medium hover:bg-gray-200 transition-colors flex items-center space-x-1">
            <Edit className="w-3 h-3" />
            <span>Edit Profile</span>
          </button>
        </div>

        {/* Achievement Badges */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 bg-green-100 px-3 py-2 rounded-lg">
            <Award className="w-4 h-4 text-green-600" />
            <span className="text-sm font-medium text-green-800">Early Bird</span>
          </div>
          <div className="flex items-center space-x-2 bg-blue-100 px-3 py-2 rounded-lg">
            <Award className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-medium text-blue-800">Calorie Crusher</span>
          </div>
          <div className="flex items-center space-x-2 bg-purple-100 px-3 py-2 rounded-lg">
            <Award className="w-4 h-4 text-purple-600" />
            <span className="text-sm font-medium text-purple-800">Perfect Score</span>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Company Information */}
        <motion.div
          className="bg-white rounded-xl shadow-sm border border-gray-100 p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Company Information</h2>
          
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-medium text-gray-600 mb-1">Company Name</h3>
              <p className="text-gray-900">{company.name}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-600 mb-1">Number of Participants</h3>
              {isEditing ? (
                <input
                  type="number"
                  value={participants}
                  onChange={(e) => setParticipants(parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-gray-900"
                  min="1"
                />
              ) : (
                <p className="text-gray-900">{participants}</p>
              )}
            </div>
          </div>
        </motion.div>

        {/* Contact Person */}
        <motion.div
          className="bg-white rounded-xl shadow-sm border border-gray-100 p-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <h2 className="text-lg font-semibold text-gray-900 mb-6">Contact Person</h2>
          
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-medium text-gray-600 mb-1">Full Name</h3>
              <p className="text-gray-900">{company.contact_name} {company.contact_last_name}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-600 mb-1">Email</h3>
              <p className="text-gray-900">{company.email}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-gray-600 mb-1">Phone</h3>
              <p className="text-gray-900">{company.phone}</p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Bottom Actions */}
      <div className="flex items-center justify-between">
        {/* Preview button hidden */}
        {/* <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors">
          Preview
        </button> */}
      </div>
    </div>
  );
}
