import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Company, Upload } from '../types';
import { TaskForm } from './TaskForm';
import { motion } from 'framer-motion';
import { 
  BarChart3, 
  Building2, 
  TrendingUp, 
  Settings, 
  HelpCircle,
  Users,
  Trophy,
  LogOut,
  ArrowRight,
  Flame,
  Award,
  TrendingUp as TrendingUpIcon,
  TrendingDown,
  Minus,
  Eye,
  Plus,
  Edit,
  Trash2,
  Check,
  X,
  Mail,
  Target,
  Clock,
  CheckCircle,
  Video,
  RefreshCw,
  Menu
} from 'lucide-react';
import toast from 'react-hot-toast';

type AdminSection = 'overview' | 'companies' | 'analytics' | 'leaderboard' | 'settings';

export function AdminDashboard() {
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState<AdminSection>('overview');
  const [companies, setCompanies] = useState<Company[]>([]);
  const [uploads, setUploads] = useState<Upload[]>([]);
  const [loading, setLoading] = useState(true);
  const [chartTooltip, setChartTooltip] = useState<{ company: string; value: number } | null>(null);
  const [activeCompanyTab, setActiveCompanyTab] = useState<'overview' | 'companies' | 'analytics' | 'submissions' | 'settings'>('companies');
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [selectedSubmission, setSelectedSubmission] = useState<Upload | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [processingUploads, setProcessingUploads] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchData();
  }, []);

  // Real-time subscriptions disabled to avoid WebSocket errors
  // useEffect(() => {
  //   const uploadsChannel = supabase
  //     .channel('admin-uploads')
  //     .on(
  //       'postgres_changes',
  //       {
  //         event: '*',
  //         schema: 'public',
  //         table: 'uploads',
  //       },
  //       () => {
  //         fetchData(); // Refresh data when uploads change
  //       }
  //     )
  //     .subscribe();

  //   const companiesChannel = supabase
  //     .channel('admin-companies')
  //     .on(
  //       'postgres_changes',
  //       {
  //         event: '*',
  //         schema: 'public',
  //         table: 'companies',
  //       },
  //       () => {
  //         fetchData(); // Refresh data when companies change
  //       }
  //     )
  //     .subscribe();

  //   return () => {
  //     supabase.removeChannel(uploadsChannel);
  //     supabase.removeChannel(companiesChannel);
  //   };
  // }, []);

  const fetchData = async () => {
    try {
      const [companiesResult, uploadsResult] = await Promise.all([
        supabase.from('companies').select('*').order('total_points', { ascending: false }),
        supabase.from('uploads').select('*').order('created_at', { ascending: false })
      ]);

      if (companiesResult.error) {
        console.error('Companies fetch error:', companiesResult.error);
        throw companiesResult.error;
      }
      if (uploadsResult.error) {
        console.error('Uploads fetch error:', uploadsResult.error);
        throw uploadsResult.error;
      }

      console.log('Fetched companies:', companiesResult.data);
      console.log('Fetched uploads:', uploadsResult.data);
      
      // Check for any pending uploads
      const pendingUploads = uploadsResult.data?.filter(upload => upload.status === 'pending') || [];
      const approvedUploads = uploadsResult.data?.filter(upload => upload.status === 'approved') || [];
      const rejectedUploads = uploadsResult.data?.filter(upload => upload.status === 'rejected') || [];
      
      console.log('Upload status breakdown:', {
        pending: pendingUploads.length,
        approved: approvedUploads.length,
        rejected: rejectedUploads.length
      });

      setCompanies(companiesResult.data || []);
      setUploads(uploadsResult.data || []);
    } catch (error) {
      toast.error('Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  const getTotalParticipants = () => {
    return companies.reduce((sum, company) => sum + (company.participant_count || 0), 0);
  };

  const getTotalPoints = () => {
    return companies.reduce((sum, company) => sum + company.total_points, 0);
  };

  const getPendingReviews = () => {
    return uploads.filter(upload => upload.status === 'pending').length;
  };

  const getTotalCalories = () => {
    return companies.reduce((sum, company) => sum + company.total_calories, 0);
  };

  const getTimeAgo = (dateString: string) => {
    const now = new Date();
    const date = new Date(dateString);
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) {
      return 'just now';
    } else if (diffInSeconds < 3600) {
      const minutes = Math.floor(diffInSeconds / 60);
      return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
    } else if (diffInSeconds < 86400) {
      const hours = Math.floor(diffInSeconds / 3600);
      return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else {
      const days = Math.floor(diffInSeconds / 86400);
      return `${days} day${days > 1 ? 's' : ''} ago`;
    }
  };

  const getWeeklyActivity = () => {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const now = new Date();
    const startOfWeek = new Date(now);
    startOfWeek.setDate(now.getDate() - now.getDay() + 1); // Start from Monday
    
    return days.map((day, index) => {
      const dayDate = new Date(startOfWeek);
      dayDate.setDate(startOfWeek.getDate() + index);
      
      // Count uploads for this day
      const dayUploads = uploads.filter(upload => {
        const uploadDate = new Date(upload.created_at);
        return uploadDate.toDateString() === dayDate.toDateString();
      });
      
      return {
        day,
        activity: dayUploads.length
      };
    });
  };

  const getRecentSubmissions = () => {
    return uploads
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, 5) // Show 5 most recent submissions
      .map(upload => {
        const company = companies.find(c => c.id === upload.company_id);
        return {
          ...upload,
          company_name: company?.name || 'Unknown Company'
        };
      });
  };

  const getChartData = () => {
    const colors = ['#3B82F6', '#F87171', '#10B981', '#8B5CF6', '#F97316', '#06B6D4', '#84CC16', '#F59E0B'];
    
    console.log('getChartData - companies:', companies);
    
    // If no companies or all have 0 points, show a default state
    if (companies.length === 0) {
      console.log('No companies found');
      return [{
        id: 'no-companies',
        name: 'No Companies',
        value: 1,
        color: '#E5E7EB'
      }];
    }
    
    const sortedCompanies = companies
      .sort((a, b) => b.total_points - a.total_points)
      .slice(0, 8); // Show top 8 companies
    
    console.log('Sorted companies:', sortedCompanies);
    
    // If all companies have 0 points, show them with equal distribution
    if (sortedCompanies.every(c => c.total_points === 0)) {
      console.log('All companies have 0 points, showing equal distribution');
      return sortedCompanies.map((company, index) => ({
        id: company.id,
        name: company.name,
        value: 1, // Equal value for all
        color: colors[index % colors.length]
      }));
    }
    
    const chartData = sortedCompanies.map((company, index) => ({
      id: company.id,
      name: company.name,
      value: company.total_points || 0,
      color: colors[index % colors.length]
    }));
    
    console.log('Final chart data:', chartData);
    return chartData;
  };

  const createDonutPath = (startAngle: number, endAngle: number, radius: number, innerRadius: number) => {
    const start = polarToCartesian(radius, endAngle);
    const end = polarToCartesian(radius, startAngle);
    const innerStart = polarToCartesian(innerRadius, endAngle);
    const innerEnd = polarToCartesian(innerRadius, startAngle);
    
    const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";
    
    return [
      "M", start.x, start.y,
      "A", radius, radius, 0, largeArcFlag, 0, end.x, end.y,
      "L", innerEnd.x, innerEnd.y,
      "A", innerRadius, innerRadius, 0, largeArcFlag, 1, innerStart.x, innerStart.y,
      "Z"
    ].join(" ");
  };

  const polarToCartesian = (radius: number, angleInDegrees: number) => {
    const angleInRadians = (angleInDegrees - 90) * Math.PI / 180.0;
    return {
      x: radius + (radius * Math.cos(angleInRadians)),
      y: radius + (radius * Math.sin(angleInRadians))
    };
  };

  const handleApproveUpload = async (uploadId: string) => {
    setProcessingUploads(prev => new Set(prev).add(uploadId));
    try {
      // First get the upload details to find the task and company
      const { data: upload, error: fetchError } = await supabase
        .from('uploads')
        .select(`
          *,
          tasks!inner(target_calories),
          companies!inner(id, name)
        `)
        .eq('id', uploadId)
        .single();

      if (fetchError) throw fetchError;

      // Update upload status and award points
      const { error: updateError } = await supabase
        .from('uploads')
        .update({ 
          status: 'approved',
          points_awarded: upload.tasks.target_calories
        })
        .eq('id', uploadId);

      if (updateError) throw updateError;

      // Update company stats using the database function
      console.log('Updating company stats:', {
        company_id: upload.company_id,
        points_to_add: upload.tasks.target_calories,
        calories_to_add: upload.tasks.target_calories
      });
      
      const { error: statsError } = await supabase.rpc('update_company_stats', {
        company_id: upload.company_id,
        points_to_add: upload.tasks.target_calories,
        calories_to_add: upload.tasks.target_calories
      });

      if (statsError) {
        console.error('Stats update error:', statsError);
        throw statsError;
      }
      
      console.log('Company stats updated successfully');
      
      toast.success(`Upload approved! ${upload.companies.name} earned ${upload.tasks.target_calories} points!`);
      
      // Close modal if it's open for this submission
      if (selectedSubmission && selectedSubmission.id === uploadId) {
        setSelectedSubmission(null);
      }
      
      // Refresh data immediately after successful operations
      console.log('Refreshing data after approval...');
      await fetchData();
    } catch (error) {
      console.error('Approval error:', error);
      toast.error('Failed to approve upload');
    } finally {
      setProcessingUploads(prev => {
        const newSet = new Set(prev);
        newSet.delete(uploadId);
        return newSet;
      });
    }
  };

  const handleRejectUpload = async (uploadId: string) => {
    setProcessingUploads(prev => new Set(prev).add(uploadId));
    try {
      // Get upload details for better feedback
      const { data: upload, error: fetchError } = await supabase
        .from('uploads')
        .select(`
          *,
          companies!inner(name)
        `)
        .eq('id', uploadId)
        .single();

      if (fetchError) throw fetchError;

      const { error } = await supabase
        .from('uploads')
        .update({ status: 'rejected' })
        .eq('id', uploadId);

      if (error) throw error;
      
      toast.success(`Upload from ${upload.companies.name} has been rejected`);
      
      // Close modal if it's open for this submission
      if (selectedSubmission && selectedSubmission.id === uploadId) {
        setSelectedSubmission(null);
      }
      
      // Refresh data immediately after successful operations
      console.log('Refreshing data after rejection...');
      await fetchData();
    } catch (error) {
      console.error('Rejection error:', error);
      toast.error('Failed to reject upload');
    } finally {
      setProcessingUploads(prev => {
        const newSet = new Set(prev);
        newSet.delete(uploadId);
        return newSet;
      });
    }
  };

  const getRankChange = (index: number) => {
    // For now, return no change since we don't have historical rank data
    // TODO: Implement proper rank change tracking with historical data
    return { type: 'same', value: 0 };
  };

  const getChangeIcon = (change: { type: string; value: number }) => {
    switch (change.type) {
      case 'up':
        return <TrendingUpIcon className="w-4 h-4 text-green-500" />;
      case 'down':
        return <TrendingDown className="w-4 h-4 text-red-500" />;
      default:
        return <Minus className="w-4 h-4 text-gray-400" />;
    }
  };

  const getChangeColor = (change: { type: string; value: number }) => {
    switch (change.type) {
      case 'up':
        return 'text-green-500';
      case 'down':
        return 'text-red-500';
      default:
        return 'text-gray-400';
    }
  };

  const handleSwitchToCompany = () => {
    navigate('/');
  };

  const handleLogout = () => {
    navigate('/signout');
  };

  const navigationItems = [
    { id: 'overview' as AdminSection, label: 'Competition Overview', icon: BarChart3 },
    { id: 'companies' as AdminSection, label: 'Company Management', icon: Building2 },
    { id: 'analytics' as AdminSection, label: 'Analytics', icon: TrendingUp },
    { id: 'leaderboard' as AdminSection, label: 'Global Leaderboard', icon: Trophy },
    { id: 'settings' as AdminSection, label: 'System Settings', icon: Settings },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex w-full">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        fixed lg:static inset-y-0 left-0 z-50 w-64 bg-white shadow-lg flex flex-col
        transform transition-transform duration-300 ease-in-out
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Logo and Admin Info */}
        <div className="p-6 border-b border-gray-100">
          {/* Mobile Close Button */}
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden absolute top-4 right-4 p-2 rounded-md text-gray-400 hover:text-gray-600 hover:bg-gray-100"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="mb-4">
            <div className="flex items-center space-x-3 mb-3">
              <img 
                src="/eisw.jpeg" 
                alt="CISW Logo" 
                className="w-12 h-12 object-contain"
              />
              <div>
                <h1 className="text-lg font-bold text-gray-900">Curaçao Sports Week</h1>
                <p className="text-sm text-gray-600">Super Admin</p>
              </div>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-red-500 rounded-full"></div>
              <span className="text-sm font-medium text-gray-900">CISW Administrator</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-600">Total Companies</span>
              <div className="bg-purple-100 text-gray-900 px-2 py-1 rounded-full text-sm font-medium">
                {companies.length} active
              </div>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4">
          <ul className="space-y-2">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              
              return (
                <li key={item.id}>
                  <button
                    onClick={() => {
                      setActiveSection(item.id);
                      setSidebarOpen(false); // Close sidebar on mobile after navigation
                    }}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                      isActive
                        ? 'bg-blue-500 text-white'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{item.label}</span>
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Bottom Actions */}
        <div className="p-4 border-t border-gray-100 space-y-2">
          <button
            onClick={handleSwitchToCompany}
            className="w-full flex items-center justify-center space-x-2 px-3 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors"
          >
            <ArrowRight className="w-4 h-4" />
            <span>Switch to Company</span>
          </button>
          <button
            onClick={handleLogout}
            className="w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col w-full">
        {/* Mobile Header */}
        <div className="lg:hidden bg-white shadow-sm border-b border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setSidebarOpen(true)}
              className="p-2 rounded-md text-gray-400 hover:text-gray-600 hover:bg-gray-100"
            >
              <Menu className="w-6 h-6" />
            </button>
            <h1 className="text-xl font-bold text-gray-900">
              {activeSection === 'overview' && 'Competition Overview'}
              {activeSection === 'companies' && 'Company Management'}
              {activeSection === 'analytics' && 'Analytics'}
              {activeSection === 'leaderboard' && 'Global Leaderboard'}
              {activeSection === 'settings' && 'System Settings'}
            </h1>
            <div className="w-10"></div> {/* Spacer for centering */}
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 p-6 w-full">
          {activeSection === 'leaderboard' && (
            <div className="space-y-8">
              {/* Page Title */}
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Global Leaderboard</h1>
                <p className="text-gray-600">See how your team ranks against other companies</p>
              </div>

              {/* Top Performers Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full">
                {companies.slice(0, 3).map((company, index) => {
                  // Calculate achievements (approved uploads) for this company
                  const achievements = uploads.filter(upload => 
                    upload.company_id === company.id && upload.status === 'approved'
                  ).length;
                  
                  return (
                    <motion.div
                      key={company.id}
                      className={`p-6 rounded-xl border ${
                        index === 1 
                          ? 'bg-white border-yellow-300 shadow-lg' 
                          : 'bg-white border-gray-200'
                      }`}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                    >
                      <div className="text-center">
                        <div className="mb-4">
                          <img 
                            src="/eisw.jpeg" 
                            alt="CISW Logo" 
                            className="w-12 h-12 object-contain mx-auto mb-2"
                          />
                        </div>
                        <h3 className="text-lg font-bold text-gray-900 mb-4">{company.name}</h3>
                        
                        <div className="space-y-2 mb-4">
                          <div className="flex items-center justify-center space-x-2">
                            <Flame className="w-4 h-4 text-gray-600" />
                            <span className="text-sm text-gray-600">{company.total_calories.toLocaleString()} calories</span>
                          </div>
                          <div className="flex items-center justify-center space-x-2">
                            <Users className="w-4 h-4 text-gray-600" />
                            <span className="text-sm text-gray-600">{company.participant_count || 0}</span>
                          </div>
                          <div className="flex items-center justify-center space-x-2">
                            <Award className="w-4 h-4 text-gray-600" />
                            <span className="text-sm text-gray-600">{achievements} achievements</span>
                          </div>
                        </div>
                        
                        <p className="text-2xl font-bold text-orange-600">{company.total_points}</p>
                      </div>
                    </motion.div>
                  );
                })}
              </div>

              {/* Complete Leaderboard */}
              <div className="bg-white rounded-xl shadow-sm border border-gray-100">
                <div className="p-6 border-b border-gray-200">
                  <div className="flex items-center justify-between">
                    <h2 className="text-lg font-semibold text-gray-900">Complete Leaderboard</h2>
                    <div className="bg-gray-100 px-3 py-1 rounded-full text-sm font-medium text-gray-700">
                      {companies.length} Teams
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  <div className="space-y-4">
                    {companies.map((company, index) => {
                      const rankChange = getRankChange(index);
                      // Calculate achievements (approved uploads) for this company
                      const achievements = uploads.filter(upload => 
                        upload.company_id === company.id && upload.status === 'approved'
                      ).length;
                      
                      return (
                        <motion.div
                          key={company.id}
                          className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.4, delay: index * 0.1 }}
                        >
                          <div className="flex items-center space-x-4">
                            <div className="flex items-center justify-center w-10 h-10 bg-white rounded-lg shadow-sm">
                              {index === 0 ? (
                                <Trophy className="w-6 h-6 text-yellow-500" />
                              ) : index === 1 ? (
                                <Trophy className="w-6 h-6 text-gray-400" />
                              ) : index === 2 ? (
                                <Trophy className="w-6 h-6 text-orange-500" />
                              ) : (
                                <div className="w-6 h-6 flex items-center justify-center text-gray-500 font-bold">{index + 1}</div>
                              )}
                            </div>
                            
                            <img 
                              src="/eisw.jpeg" 
                              alt="CISW Logo" 
                              className="w-8 h-8 object-contain rounded-lg"
                            />
                            <div>
                              <h3 className="font-semibold text-gray-900">{company.name}</h3>
                              <div className="flex items-center space-x-4 text-sm text-gray-600">
                                <div className="flex items-center space-x-1">
                                  <Users className="w-3 h-3" />
                                  <span>{company.participant_count || 0}</span>
                                </div>
                                <div className="flex items-center space-x-1">
                                  <Flame className="w-3 h-3" />
                                  <span>{company.total_calories.toLocaleString()} cal</span>
                                </div>
                                {achievements > 0 && (
                                  <div className="flex items-center space-x-1">
                                    <Award className="w-3 h-3" />
                                    <span>{achievements}</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-4">
                            <div className="text-right">
                              <p className="text-lg font-bold text-gray-900">{company.total_points}</p>
                            </div>
                            
                            <div className="flex items-center space-x-1">
                              {getChangeIcon(rankChange)}
                              <span className={`text-sm font-medium ${getChangeColor(rankChange)}`}>
                                {rankChange.type === 'up' ? `+${rankChange.value}` : 
                                 rankChange.type === 'down' ? `-${rankChange.value}` : '-'}
                              </span>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Summary Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full">
                <motion.div
                  className="bg-white rounded-xl p-8 shadow-sm border border-gray-100 text-center"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.5 }}
                >
                  <Trophy className="w-12 h-12 text-yellow-500 mx-auto mb-4" />
                  <p className="text-3xl font-bold text-gray-900 mb-2">{companies[0]?.total_points || 0}</p>
                  <p className="text-gray-600">Leading Score</p>
                </motion.div>

                <motion.div
                  className="bg-white rounded-xl p-8 shadow-sm border border-gray-100 text-center"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.6 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    {/* Preview button hidden */}
                    {/* <button className="px-3 py-1 bg-gray-100 text-gray-700 rounded text-sm font-medium hover:bg-gray-200 transition-colors">
                      Preview
                    </button> */}
                  </div>
                  <Flame className="w-12 h-12 text-orange-500 mx-auto mb-4" />
                  <p className="text-3xl font-bold text-gray-900 mb-2">{getTotalCalories().toLocaleString()}</p>
                  <p className="text-gray-600">Total Calories</p>
                </motion.div>

                <motion.div
                  className="bg-white rounded-xl p-8 shadow-sm border border-gray-100 text-center"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.7 }}
                >
                  <Users className="w-12 h-12 text-blue-500 mx-auto mb-4" />
                  <p className="text-3xl font-bold text-gray-900 mb-2">{getTotalParticipants()}</p>
                  <p className="text-gray-600">Total Participants</p>
                </motion.div>
              </div>
            </div>
          )}

          {activeSection === 'overview' && (
            <div className="space-y-8">
              {/* Page Title */}
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-gray-900 mb-2">Competition Overview</h1>
                  <p className="text-gray-600">Get an overview of the competition</p>
                </div>
                <div className="flex items-center space-x-4">
                  <button 
                    onClick={fetchData}
                    className="flex items-center space-x-2 px-4 py-2 bg-gray-500 text-white rounded-lg text-sm font-medium hover:bg-gray-600 transition-colors"
                  >
                    <RefreshCw className="w-4 h-4" />
                    <span>Refresh</span>
                  </button>
                  <button 
                    onClick={() => setShowTaskForm(true)}
                    className="flex items-center space-x-2 px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Create Task</span>
                  </button>
                </div>
              </div>

              {/* Key Metrics Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 w-full">
                {loading ? (
                  // Loading skeleton for metrics cards
                  Array.from({ length: 4 }).map((_, index) => (
                    <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 animate-pulse">
                      <div className="flex items-center justify-between mb-4">
                        <div className="w-10 h-10 bg-gray-200 rounded-lg"></div>
                        <div className="w-16 h-8 bg-gray-200 rounded"></div>
                      </div>
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-8 bg-gray-200 rounded mb-1"></div>
                      <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                    </div>
                  ))
                ) : (
                  <>
                <motion.div
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.1 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Building2 className="w-5 h-5 text-blue-600" />
                    </div>
                    <div className="w-16 h-8 bg-gray-100 rounded flex items-center justify-center">
                      <div className="w-12 h-1 bg-gray-300 rounded"></div>
                    </div>
                  </div>
                  <h3 className="text-sm font-medium text-gray-600 mb-1">TOTAL COMPANIES</h3>
                  <p className="text-2xl font-bold text-gray-900 mb-1">{companies.length}</p>
                  <p className="text-sm text-gray-500">active participants</p>
                </motion.div>

                <motion.div
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <Users className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="w-16 h-8 bg-gray-100 rounded flex items-center justify-center">
                      <div className="w-12 h-1 bg-gray-300 rounded"></div>
                    </div>
                  </div>
                  <h3 className="text-sm font-medium text-gray-600 mb-1">TOTAL PARTICIPANTS</h3>
                  <p className="text-2xl font-bold text-gray-900 mb-1">{getTotalParticipants()}</p>
                  <p className="text-sm text-gray-500">across all companies</p>
                </motion.div>

                <motion.div
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.3 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                      <Trophy className="w-5 h-5 text-yellow-600" />
                    </div>
                    <div className="w-16 h-8 bg-gray-100 rounded flex items-center justify-center">
                      <div className="w-12 h-1 bg-gray-300 rounded"></div>
                    </div>
                  </div>
                  <h3 className="text-sm font-medium text-gray-600 mb-1">TOTAL POINTS</h3>
                  <p className="text-2xl font-bold text-gray-900 mb-1">{getTotalPoints().toLocaleString()}</p>
                  <p className="text-sm text-gray-500">avg: {Math.round(getTotalPoints() / companies.length)} per company</p>
                </motion.div>

                <motion.div
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.4 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                      <Eye className="w-5 h-5 text-orange-600" />
                    </div>
                    <div className="w-16 h-8 bg-gray-100 rounded flex items-center justify-center">
                      <div className="w-12 h-1 bg-gray-300 rounded"></div>
                    </div>
                  </div>
                  <h3 className="text-sm font-medium text-gray-600 mb-1">PENDING REVIEWS</h3>
                  <p className="text-2xl font-bold text-gray-900 mb-1">{getPendingReviews()}</p>
                  <p className="text-sm text-gray-500">requiring attention</p>
                </motion.div>
                  </>
                )}
              </div>

              {/* Charts Section */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {loading ? (
                  // Loading skeleton for charts
                  Array.from({ length: 2 }).map((_, index) => (
                    <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 animate-pulse">
                      <div className="h-6 bg-gray-200 rounded mb-6 w-1/3"></div>
                      <div className="space-y-4">
                        {Array.from({ length: 7 }).map((_, i) => (
                          <div key={i} className="flex items-center space-x-4">
                            <div className="w-8 h-4 bg-gray-200 rounded"></div>
                            <div className="flex-1 h-2 bg-gray-200 rounded"></div>
                            <div className="w-8 h-4 bg-gray-200 rounded"></div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))
                ) : (
                  <>
                {/* Weekly Activity Chart */}
                <motion.div
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.5 }}
                >
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-semibold text-gray-900">Weekly Activity</h3>
                    {/* Preview button hidden */}
                    {/* <button className="px-3 py-1 bg-gray-100 text-gray-700 rounded text-sm font-medium hover:bg-gray-200 transition-colors">
                      Preview
                    </button> */}
                  </div>
                  <div className="space-y-4">
                    {(() => {
                      const weeklyData = getWeeklyActivity();
                      const maxActivity = Math.max(...weeklyData.map(d => d.activity), 1);
                      
                      return weeklyData.map((day) => (
                        <div key={day.day} className="flex items-center space-x-4">
                          <div className="w-8 text-sm text-gray-600">{day.day}</div>
                          <div className="flex-1 bg-gray-200 rounded-full h-2 relative group">
                            <div
                              className="bg-blue-500 h-2 rounded-full transition-all duration-500 hover:bg-blue-600"
                              style={{ width: `${(day.activity / maxActivity) * 100}%` }}
                            ></div>
                            <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-gray-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                              {day.day} submissions: {day.activity}
                            </div>
                          </div>
                          <div className="w-8 text-sm text-gray-600 text-right">{day.activity}</div>
                        </div>
                      ));
                    })()}
                  </div>
                </motion.div>

                {/* Company Distribution Chart */}
                <motion.div
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.6 }}
                >
                  <div className="flex items-center space-x-2 mb-6">
                    <Target className="w-5 h-5 text-gray-600" />
                    <h3 className="text-lg font-semibold text-gray-900">Company Distribution</h3>
                  </div>
                  {companies.length === 0 ? (
                    <div className="text-center py-8">
                      <Target className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                      <p className="text-gray-500">No companies registered yet</p>
                      <p className="text-sm text-gray-400 mt-2">Companies will appear here once they register</p>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center h-64">
                      <div className="relative w-full">
                        {/* Simple Bar Chart */}
                        <div className="space-y-3">
                          {getChartData().slice(0, 5).map((segment, index) => {
                            const total = getChartData().reduce((sum, item) => sum + item.value, 0);
                            const percentage = total > 0 ? (segment.value / total) * 100 : 0;
                            
                            return (
                              <div key={segment.id} className="flex items-center space-x-3">
                                <div className="w-20 text-sm text-gray-600 truncate">
                                  {segment.name}
                                </div>
                                <div className="flex-1 bg-gray-200 rounded-full h-4 relative">
                                  <div 
                                    className="h-4 rounded-full transition-all duration-500"
                                    style={{ 
                                      width: `${percentage}%`,
                                      backgroundColor: segment.color 
                                    }}
                                  ></div>
                                </div>
                                <div className="w-16 text-sm text-gray-500 text-right">
                                  {segment.value} pts
                                </div>
                              </div>
                            );
                          })}
                        </div>
                        
                        {/* Total Points Display */}
                        <div className="mt-6 text-center">
                          <div className="text-2xl font-bold text-gray-700">
                            {getChartData().reduce((sum, item) => sum + item.value, 0)}
                          </div>
                          <div className="text-sm text-gray-500">Total Points</div>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {/* Legend */}
                  {companies.length > 0 && (
                    <div className="mt-4 space-y-2">
                      {getChartData().map((segment, index) => (
                        <div key={segment.id} className="flex items-center space-x-2 text-sm">
                          <div 
                            className="w-3 h-3 rounded-full" 
                            style={{ backgroundColor: segment.color }}
                          ></div>
                          <span className="text-gray-600">{segment.name}</span>
                          <span className="text-gray-400">({segment.value} pts)</span>
                        </div>
                      ))}
                    </div>
                  )}
                </motion.div>
                  </>
                )}
              </div>

              {/* Recent Submissions */}
              {loading ? (
                <div className="bg-white rounded-xl shadow-sm border border-gray-100 animate-pulse">
                  <div className="p-6 border-b border-gray-200">
                    <div className="h-6 bg-gray-200 rounded w-1/3"></div>
                  </div>
                  <div className="p-6">
                    <div className="space-y-4">
                      {Array.from({ length: 3 }).map((_, index) => (
                        <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-4">
                            <div className="w-10 h-10 bg-gray-200 rounded-lg"></div>
                            <div>
                              <div className="h-4 bg-gray-200 rounded mb-2 w-32"></div>
                              <div className="h-3 bg-gray-200 rounded mb-1 w-24"></div>
                              <div className="h-3 bg-gray-200 rounded w-20"></div>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            <div className="w-8 h-6 bg-gray-200 rounded"></div>
                            <div className="w-8 h-8 bg-gray-200 rounded"></div>
                            <div className="w-8 h-8 bg-gray-200 rounded"></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <motion.div
                  className="bg-white rounded-xl shadow-sm border border-gray-100"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.7 }}
                >
                  <div className="p-6 border-b border-gray-200">
                    <h2 className="text-lg font-semibold text-gray-900">Recent Submissions</h2>
                  </div>
                  <div className="p-6">
                    <div className="space-y-4">
                      {getRecentSubmissions().map((submission, index) => (
                      <motion.div
                        key={`recent-${submission.id}-${submission.status}`}
                        className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.4, delay: index * 0.1 }}
                      >
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <Building2 className="w-5 h-5 text-blue-600" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900">Task Submission</h3>
                            <p className="text-sm text-gray-600">from {submission.company_name}</p>
                            <p className="text-xs text-gray-500">submitted {getTimeAgo(submission.created_at)}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className={`px-2 py-1 text-xs font-medium rounded ${
                            submission.status === 'pending' 
                              ? 'bg-yellow-100 text-yellow-800'
                              : submission.status === 'approved'
                              ? 'bg-green-100 text-green-800'
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {submission.status}
                          </span>
                          <button
                            onClick={() => setSelectedSubmission(submission)}
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="View submission"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          {submission.status === 'pending' ? (
                            <>
                              <button
                                onClick={() => handleApproveUpload(submission.id)}
                                disabled={processingUploads.has(submission.id)}
                                className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                title="Approve submission"
                              >
                                {processingUploads.has(submission.id) ? (
                                  <div className="w-4 h-4 border-2 border-green-600 border-t-transparent rounded-full animate-spin" />
                                ) : (
                                  <Check className="w-4 h-4" />
                                )}
                              </button>
                              <button
                                onClick={() => handleRejectUpload(submission.id)}
                                disabled={processingUploads.has(submission.id)}
                                className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                title="Reject submission"
                              >
                                {processingUploads.has(submission.id) ? (
                                  <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin" />
                                ) : (
                                  <X className="w-4 h-4" />
                                )}
                              </button>
                            </>
                          ) : submission.status === 'approved' ? (
                            <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded">
                              +{submission.points_awarded || 0} pts
                            </span>
                          ) : (
                            <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs font-medium rounded">
                              {getTimeAgo(submission.created_at)}
                            </span>
                          )}
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </motion.div>
              )}
            </div>
          )}

          {activeSection === 'companies' && (
            <div className="space-y-6">
              {/* Page Title */}
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Company Management</h1>
                <p className="text-gray-600">Manage company details and participants</p>
              </div>

              {/* Tab Navigation */}
              <div className="bg-white rounded-lg border border-gray-200 p-1">
                <nav className="flex space-x-1">
                  {[
                    { key: 'overview', label: 'Overview' },
                    { key: 'companies', label: 'Companies' },
                    { key: 'analytics', label: 'Analytics' },
                    { key: 'submissions', label: 'Submissions' },
                    { key: 'settings', label: 'Settings' }
                  ].map((tab) => (
                    <button
                      key={tab.key}
                      onClick={() => setActiveCompanyTab(tab.key as any)}
                      className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                        activeCompanyTab === tab.key
                          ? 'bg-blue-50 text-blue-700' 
                          : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </nav>
              </div>

              {/* Content based on active tab */}
              {activeCompanyTab === 'overview' && (
                <div className="space-y-6">
                  {/* Charts Section */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 w-full">
                    {/* Weekly Activity Chart */}
                    <motion.div
                      className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.6 }}
                    >
                      <h3 className="text-lg font-semibold text-gray-900 mb-6">Weekly Activity</h3>
                      <div className="h-64">
                        <svg width="100%" height="100%" viewBox="0 0 400 200" className="overflow-visible">
                          {/* Grid lines */}
                          <defs>
                            <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#f3f4f6" strokeWidth="1" strokeDasharray="2,2"/>
                            </pattern>
                          </defs>
                          <rect width="100%" height="100%" fill="url(#grid)" />
                          
                          {/* Y-axis labels */}
                          {[0, 5, 10, 15, 20].map((value) => (
                            <text key={value} x="20" y={180 - (value * 8)} textAnchor="end" className="text-xs fill-gray-500">
                              {value}
                            </text>
                          ))}
                          
                          {/* X-axis labels */}
                          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => (
                            <text key={day} x={60 + (index * 40)} y="195" textAnchor="middle" className="text-xs fill-gray-500">
                              {day}
                            </text>
                          ))}
                          
                          {/* Bars */}
                          {[12, 15, 18, 14, 8, 6, 6].map((value, index) => (
                            <rect
                              key={index}
                              x={50 + (index * 40)}
                              y={180 - (value * 8)}
                              width="20"
                              height={value * 8}
                              fill="#3B82F6"
                              className="hover:fill-blue-600 transition-colors cursor-pointer"
                            />
                          ))}
                        </svg>
                      </div>
                    </motion.div>

                    {/* Company Distribution Chart */}
                    <motion.div
                      className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.6, delay: 0.1 }}
                    >
                      <div className="flex items-center space-x-2 mb-6">
                        <Target className="w-5 h-5 text-gray-600" />
                        <h3 className="text-lg font-semibold text-gray-900">Company Distribution</h3>
                      </div>
                      {companies.length === 0 ? (
                        <div className="text-center py-8">
                          <Target className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                          <p className="text-gray-500">No companies registered yet</p>
                          <p className="text-sm text-gray-400 mt-2">Companies will appear here once they register</p>
                        </div>
                      ) : (
                        <div className="flex items-center justify-center h-64">
                          <div className="relative w-full">
                            {/* Simple Bar Chart */}
                            <div className="space-y-3">
                              {getChartData().slice(0, 5).map((segment, index) => {
                                const total = getChartData().reduce((sum, item) => sum + item.value, 0);
                                const percentage = total > 0 ? (segment.value / total) * 100 : 0;
                                
                                return (
                                  <div key={segment.id} className="flex items-center space-x-3">
                                    <div className="w-20 text-sm text-gray-600 truncate">
                                      {segment.name}
                                    </div>
                                    <div className="flex-1 bg-gray-200 rounded-full h-4 relative">
                                      <div 
                                        className="h-4 rounded-full transition-all duration-500"
                                        style={{ 
                                          width: `${percentage}%`,
                                          backgroundColor: segment.color 
                                        }}
                                      ></div>
                                    </div>
                                    <div className="w-16 text-sm text-gray-500 text-right">
                                      {segment.value} pts
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                            
                            {/* Total Points Display */}
                            <div className="mt-6 text-center">
                              <div className="text-2xl font-bold text-gray-700">
                                {getChartData().reduce((sum, item) => sum + item.value, 0)}
                              </div>
                              <div className="text-sm text-gray-500">Total Points</div>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {/* Legend */}
                      {companies.length > 0 && (
                        <div className="mt-4 space-y-2">
                          {getChartData().map((segment, index) => (
                            <div key={segment.id} className="flex items-center space-x-2 text-sm">
                              <div 
                                className="w-3 h-3 rounded-full" 
                                style={{ backgroundColor: segment.color }}
                              ></div>
                              <span className="text-gray-600">{segment.name}</span>
                              <span className="text-gray-400">({segment.value} pts)</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </motion.div>
                  </div>
                </div>
              )}

              {activeCompanyTab === 'companies' && (
                <div className="space-y-6">
                  {/* Section Header */}
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-xl font-semibold text-gray-900">Company Management</h2>
                      <p className="text-gray-600">Create, edit, and manage participating companies</p>
                    </div>
                    <button className="flex items-center space-x-2 px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors">
                      <Plus className="w-4 h-4" />
                      <span>Add Company</span>
                    </button>
                  </div>

                  {/* Company Cards Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 w-full">
                {companies.map((company, index) => {
                  // Calculate achievements (approved uploads) for this company
                  const achievements = uploads.filter(upload => 
                    upload.company_id === company.id && upload.status === 'approved'
                  ).length;
                  
                  return (
                  <motion.div
                    key={company.name}
                    className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 relative"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <img 
                        src={company.logo_url || "/eisw.jpeg"} 
                        alt={`${company.name} Logo`} 
                        className="w-12 h-12 object-contain rounded-lg"
                      />
                      <div className="flex items-center space-x-2">
                        <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                          <Edit className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <h3 className="text-lg font-semibold text-gray-900 mb-2">{company.name}</h3>
                    
                    <div className="space-y-3 mb-4">
                      <div className="flex items-center space-x-2">
                        <Users className="w-4 h-4 text-gray-500" />
                        <span className="text-sm text-gray-600">{company.participant_count || 0} participants</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Trophy className="w-4 h-4 text-gray-500" />
                        <span className="text-sm text-gray-600">Total Points: {company.total_points.toLocaleString()}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Flame className="w-4 h-4 text-gray-500" />
                        <span className="text-sm text-gray-600">Calories Burned: {company.total_calories.toLocaleString()}</span>
                      </div>
                      {achievements > 0 && (
                        <div className="flex items-center space-x-2">
                          <Award className="w-4 h-4 text-gray-500" />
                          <span className="text-sm text-gray-600">{achievements} achievements</span>
                        </div>
                      )}
                    </div>

                    <div className="border-t border-gray-100 pt-4">
                      <div className="flex items-center space-x-2 mb-1">
                        <Mail className="w-3 h-3 text-gray-400" />
                        <span className="text-xs text-gray-500">Contact</span>
                      </div>
                      <p className="text-sm font-medium text-gray-900">{company.contact_name} {company.contact_last_name}</p>
                      <p className="text-xs text-gray-600">{company.email}</p>
                    </div>
                  </motion.div>
                  );
                })}
                  </div>
                </div>
              )}

              {activeCompanyTab === 'analytics' && (
                <div className="space-y-6">
                  <div className="text-center py-16">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <TrendingUp className="w-8 h-8 text-gray-400" />
                    </div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-2">Analytics</h2>
                    <p className="text-gray-600">Advanced analytics and insights coming soon.</p>
                  </div>
                </div>
              )}

              {activeCompanyTab === 'submissions' && (
                <div className="space-y-6">
                  {/* Page Title */}
                  <div>
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">Submission Management</h1>
                    <p className="text-gray-600">Review and approve company task submissions</p>
                  </div>

                  {/* Pending Submissions */}
                  <div className="bg-white rounded-xl shadow-sm border border-gray-100">
                    <div className="p-6 border-b border-gray-200">
                      <h2 className="text-lg font-semibold text-gray-900">Pending Submissions</h2>
                      <p className="text-sm text-gray-600 mt-1">Review and approve company uploads</p>
                    </div>
                    <div className="p-6">
                      <div className="space-y-4">
                        {uploads
                          .filter(upload => upload.status === 'pending')
                          .map((upload, index) => (
                            <motion.div
                              key={`pending-${upload.id}`}
                              className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ duration: 0.4, delay: index * 0.1 }}
                            >
                              <div className="flex items-center space-x-4">
                                <div className="w-12 h-12 bg-white rounded-lg shadow-sm flex items-center justify-center">
                                  {upload.file_type === 'image' ? (
                                    <img
                                      src={upload.file_url}
                                      alt="Upload preview"
                                      className="w-full h-full object-cover rounded-lg"
                                    />
                                  ) : (
                                    <Video className="w-6 h-6 text-blue-600" />
                                  )}
                                </div>
                                <div>
                                  <h3 className="font-semibold text-gray-900">Task Submission</h3>
                                  <p className="text-sm text-gray-600">Company: {companies.find(c => c.id === upload.company_id)?.name || 'Unknown'}</p>
                                  <p className="text-xs text-gray-500">Uploaded: {new Date(upload.created_at).toLocaleDateString()}</p>
                                </div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <button
                                  onClick={() => setSelectedSubmission(upload)}
                                  className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                                  title="View submission"
                                >
                                  <Eye className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => handleApproveUpload(upload.id)}
                                  disabled={processingUploads.has(upload.id)}
                                  className="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                  title="Approve submission"
                                >
                                  {processingUploads.has(upload.id) ? (
                                    <div className="w-4 h-4 border-2 border-green-600 border-t-transparent rounded-full animate-spin" />
                                  ) : (
                                    <Check className="w-4 h-4" />
                                  )}
                                </button>
                                <button
                                  onClick={() => handleRejectUpload(upload.id)}
                                  disabled={processingUploads.has(upload.id)}
                                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                  title="Reject submission"
                                >
                                  {processingUploads.has(upload.id) ? (
                                    <div className="w-4 h-4 border-2 border-red-600 border-t-transparent rounded-full animate-spin" />
                                  ) : (
                                    <X className="w-4 h-4" />
                                  )}
                                </button>
                              </div>
                            </motion.div>
                          ))}
                        
                        {uploads.filter(upload => upload.status === 'pending').length === 0 && (
                          <div className="text-center py-8">
                            <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3" />
                            <p className="text-gray-600">No pending submissions</p>
                            <p className="text-sm text-gray-500 mt-1">All submissions have been reviewed</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Approved Submissions */}
                  <div className="bg-white rounded-xl shadow-sm border border-gray-100">
                    <div className="p-6 border-b border-gray-200">
                      <h2 className="text-lg font-semibold text-gray-900">Approved Submissions</h2>
                      <p className="text-sm text-gray-600 mt-1">Recently approved company uploads</p>
                    </div>
                    <div className="p-6">
                      <div className="space-y-4">
                        {uploads
                          .filter(upload => upload.status === 'approved')
                          .slice(0, 5) // Show only recent 5
                          .map((upload, index) => (
                            <motion.div
                              key={`approved-${upload.id}`}
                              className="flex items-center justify-between p-4 bg-green-50 rounded-lg border border-green-200"
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              transition={{ duration: 0.4, delay: index * 0.1 }}
                            >
                              <div className="flex items-center space-x-4">
                                <div className="w-12 h-12 bg-white rounded-lg shadow-sm flex items-center justify-center">
                                  {upload.file_type === 'image' ? (
                                    <img
                                      src={upload.file_url}
                                      alt="Upload preview"
                                      className="w-full h-full object-cover rounded-lg"
                                    />
                                  ) : (
                                    <Video className="w-6 h-6 text-blue-600" />
                                  )}
                                </div>
                                <div>
                                  <h3 className="font-semibold text-gray-900">Task Submission</h3>
                                  <p className="text-sm text-gray-600">Company: {companies.find(c => c.id === upload.company_id)?.name || 'Unknown'}</p>
                                  <p className="text-xs text-green-600">✓ Approved - {upload.points_awarded || 0} points awarded</p>
                                </div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <button
                                  onClick={() => setSelectedSubmission(upload)}
                                  className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                                  title="View submission"
                                >
                                  <Eye className="w-4 h-4" />
                                </button>
                                <div className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                                  Approved
                                </div>
                              </div>
                            </motion.div>
                          ))}
                        
                        {uploads.filter(upload => upload.status === 'approved').length === 0 && (
                          <div className="text-center py-8">
                            <Clock className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                            <p className="text-gray-600">No approved submissions yet</p>
                            <p className="text-sm text-gray-500 mt-1">Approved submissions will appear here</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeCompanyTab === 'settings' && (
                <div className="space-y-6">
                  <div className="text-center py-16">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Settings className="w-8 h-8 text-gray-400" />
                    </div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-2">Settings</h2>
                    <p className="text-gray-600">Company management settings coming soon.</p>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeSection === 'analytics' && (
            <div className="space-y-6">
              <div className="text-center py-16">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="w-8 h-8 text-gray-400" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Advanced Analytics</h2>
                <p className="text-gray-600">Detailed competition analytics and insights coming soon.</p>
              </div>
            </div>
          )}

          {activeSection === 'settings' && (
            <div className="space-y-6">
              <div className="text-center py-16">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Settings className="w-8 h-8 text-gray-400" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900 mb-2">System Settings</h2>
                <p className="text-gray-600">Global competition settings and configuration options.</p>
              </div>
            </div>
          )}
        </div>

        {/* Help Button */}
        <button className="fixed bottom-6 right-6 w-12 h-12 bg-blue-500 text-white rounded-full shadow-lg hover:bg-blue-600 transition-colors flex items-center justify-center">
          <HelpCircle className="w-6 h-6" />
        </button>
      </div>

      {/* Task Form Modal */}
      {showTaskForm && (
        <TaskForm
          onClose={() => setShowTaskForm(false)}
          onSuccess={() => {
            setShowTaskForm(false);
            fetchData(); // Refresh data to show new task
          }}
        />
      )}

      {/* Submission View Modal */}
      {selectedSubmission && (
        <motion.div 
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div 
            className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden"
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.3 }}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between p-6 border-b border-gray-200">
              <div>
                <h2 className="text-xl font-bold text-gray-900">Submission Review</h2>
                <p className="text-sm text-gray-600 mt-1">
                  Company: {companies.find(c => c.id === selectedSubmission.company_id)?.name || 'Unknown'}
                </p>
              </div>
              <button
                onClick={() => setSelectedSubmission(null)}
                className="text-gray-500 hover:text-gray-700 transition-colors duration-200"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6">
              {/* Submission Details */}
              <div className="mb-6">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Task Submission</h3>
                    <p className="text-sm text-gray-600">
                      Uploaded: {new Date(selectedSubmission.created_at).toLocaleDateString()} at {new Date(selectedSubmission.created_at).toLocaleTimeString()}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                      selectedSubmission.status === 'pending' 
                        ? 'bg-yellow-100 text-yellow-800' 
                        : selectedSubmission.status === 'approved'
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {selectedSubmission.status}
                    </span>
                    {selectedSubmission.status === 'approved' && selectedSubmission.points_awarded && (
                      <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                        +{selectedSubmission.points_awarded} points
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Media Display */}
              <div className="mb-6">
                <div className="bg-gray-50 rounded-xl p-4">
                  {selectedSubmission.file_type === 'image' ? (
                    <img
                      src={selectedSubmission.file_url}
                      alt="Submission"
                      className="w-full max-h-96 object-contain rounded-lg"
                    />
                  ) : (
                    <video
                      src={selectedSubmission.file_url}
                      controls
                      className="w-full max-h-96 rounded-lg"
                    />
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              {selectedSubmission.status === 'pending' && (
                <div className="flex items-center justify-center space-x-4">
                  <button
                    onClick={() => {
                      handleRejectUpload(selectedSubmission.id);
                      setSelectedSubmission(null);
                    }}
                    className="flex items-center space-x-2 px-6 py-3 bg-red-500 text-white rounded-lg font-medium hover:bg-red-600 transition-colors"
                  >
                    <X className="w-4 h-4" />
                    <span>Reject</span>
                  </button>
                  <button
                    onClick={() => {
                      handleApproveUpload(selectedSubmission.id);
                      setSelectedSubmission(null);
                    }}
                    className="flex items-center space-x-2 px-6 py-3 bg-green-500 text-white rounded-lg font-medium hover:bg-green-600 transition-colors"
                  >
                    <Check className="w-4 h-4" />
                    <span>Approve</span>
                  </button>
                </div>
              )}

              {selectedSubmission.status !== 'pending' && (
                <div className="text-center">
                  <p className="text-gray-600">
                    This submission has been {selectedSubmission.status}.
                    {selectedSubmission.status === 'approved' && selectedSubmission.points_awarded && (
                      <span className="block mt-2 text-green-600 font-medium">
                        {selectedSubmission.points_awarded} points have been awarded to the company.
                      </span>
                    )}
                  </p>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
}
