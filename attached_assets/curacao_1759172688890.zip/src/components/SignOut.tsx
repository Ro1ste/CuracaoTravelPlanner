import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export function SignOut() {
  const { signOut } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    let isMounted = true;
    const doSignOut = async () => {
      try {
        await signOut();
      } catch (error) {
        console.error('Error signing out:', error);
      } finally {
        setTimeout(() => {
          if (!isMounted) return;
          navigate('/', { replace: true });
        }, 400);
      }
    };
    doSignOut();
    return () => {
      isMounted = false;
    };
  }, [signOut, navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-blue-100 flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-500"></div>
    </div>
  );
}


