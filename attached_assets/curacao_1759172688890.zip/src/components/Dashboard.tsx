import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Task, Upload } from '../types';
import { TaskCard } from './TaskCard';
import { UploadModal } from './UploadModal';
import { motion } from 'framer-motion';
import { Calendar, Trophy, Target, Upload as UploadIcon } from 'lucide-react';
import toast from 'react-hot-toast';

export function Dashboard() {
  const { company, refreshCompany } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [uploads, setUploads] = useState<Upload[]>([]);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTasks();
  }, []);

  useEffect(() => {
    fetchUploads();
  }, [company]);

  const fetchTasks = async () => {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .order('day', { ascending: true });

      if (error) throw error;
      setTasks(data || []);
    } catch (error) {
      toast.error('Failed to fetch tasks');
    } finally {
      setLoading(false);
    }
  };

  const fetchUploads = async () => {
    if (!company) return;

    try {
      const { data, error } = await supabase
        .from('uploads')
        .select('*')
        .eq('company_id', company.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setUploads(data || []);
    } catch (error) {
      toast.error('Failed to fetch uploads');
    }
  };

  const handleUploadSuccess = () => {
    fetchUploads();
    refreshCompany();
    setShowUploadModal(false);
    toast.success('Upload submitted for review!');
  };

  const getTaskUpload = (taskId: string) => {
    return uploads.find(upload => upload.task_id === taskId);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <motion.div 
        className="text-center"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome to Sportsweek Challenge!</h1>
        <p className="text-lg text-gray-600">Complete daily tasks and upload your proof to earn points</p>
      </motion.div>

      <motion.div 
        className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-6 rounded-2xl border border-orange-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-orange-800">Total Points</h3>
            <Trophy className="w-6 h-6 text-orange-600" />
          </div>
          <p className="text-3xl font-bold text-orange-900">{company?.total_points || 0}</p>
        </div>

        <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-2xl border border-green-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-green-800">Calories Burned</h3>
            <Target className="w-6 h-6 text-green-600" />
          </div>
          <p className="text-3xl font-bold text-green-900">{company?.total_calories || 0}</p>
        </div>

        <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-2xl border border-blue-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-blue-800">Tasks Completed</h3>
            <Calendar className="w-6 h-6 text-blue-600" />
          </div>
          <p className="text-3xl font-bold text-blue-900">
            {uploads.filter(u => u.status === 'approved').length}
          </p>
        </div>
      </motion.div>

      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Weekly Tasks</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {tasks.map((task, index) => {
            const upload = getTaskUpload(task.id);
            return (
              <motion.div
                key={task.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <TaskCard 
                  task={task} 
                  upload={upload}
                  onUpload={(task) => {
                    if (!company) {
                      toast.error('Your company profile is still loading. Please try again.');
                      return;
                    }
                    setSelectedTask(task);
                    setShowUploadModal(true);
                  }}
                />
              </motion.div>
            );
          })}
        </div>
      </div>

      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-6">My Uploads</h2>
        {uploads.length === 0 ? (
          <div className="text-center py-8 text-gray-600">No uploads yet.</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {uploads.map((upload, index) => (
              <motion.div
                key={upload.id}
                className="bg-white rounded-2xl shadow-lg border border-gray-100 p-4"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
              >
                <div className="mb-3">
                  {upload.file_type === 'image' ? (
                    <img
                      src={upload.file_url}
                      alt="Upload"
                      className="w-full h-40 object-cover rounded-lg"
                    />
                  ) : (
                    <video
                      src={upload.file_url}
                      controls
                      className="w-full h-40 object-cover rounded-lg"
                    />
                  )}
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Status:</span>
                  <span className={`text-sm font-medium ${
                    upload.status === 'approved' ? 'text-green-600' : upload.status === 'rejected' ? 'text-red-600' : 'text-yellow-600'
                  }`}>
                    {upload.status}
                  </span>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {company && showUploadModal && selectedTask && (
        <UploadModal
          task={selectedTask}
          companyId={company.id}
          onClose={() => setShowUploadModal(false)}
          onSuccess={handleUploadSuccess}
        />
      )}
    </div>
  );
}