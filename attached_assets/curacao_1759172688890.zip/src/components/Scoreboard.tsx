import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Company } from '../types';
import { motion } from 'framer-motion';
import { Trophy, Medal, Award, Target, Building2, Users, Flame, TrendingUp, TrendingDown, Minus } from 'lucide-react';

export function Scoreboard() {
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchScoreboard();

    // Real-time subscription disabled to avoid WebSocket errors
    // const subscription = supabase
    //   .channel('scoreboard')
    //   .on('postgres_changes', 
    //     { event: '*', schema: 'public', table: 'companies' }, 
    //     fetchScoreboard
    //   )
    //   .subscribe();

    // return () => {
    //   subscription.unsubscribe();
    // };
  }, []);

  const fetchScoreboard = async () => {
    try {
      const { data, error } = await supabase
        .from('companies')
        .select('*')
        .order('total_points', { ascending: false })
        .order('total_calories', { ascending: false });

      if (error) throw error;
      setCompanies(data || []);
    } catch (error) {
      console.error('Error fetching scoreboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRankIcon = (index: number) => {
    switch (index) {
      case 0:
        return <Trophy className="w-6 h-6 text-yellow-500" />;
      case 1:
        return <Medal className="w-6 h-6 text-gray-400" />;
      case 2:
        return <Award className="w-6 h-6 text-orange-500" />;
      default:
        return <div className="w-6 h-6 flex items-center justify-center text-gray-500 font-bold">{index + 1}</div>;
    }
  };

  const getRankChange = (index: number) => {
    // Mock data for rank changes
    const changes = [
      { type: 'up', value: 1 },
      { type: 'down', value: 1 },
      { type: 'same', value: 0 },
      { type: 'up', value: 2 },
      { type: 'down', value: 1 }
    ];
    return changes[index] || { type: 'same', value: 0 };
  };

  const getChangeIcon = (change: { type: string; value: number }) => {
    switch (change.type) {
      case 'up':
        return <TrendingUp className="w-4 h-4 text-green-500" />;
      case 'down':
        return <TrendingDown className="w-4 h-4 text-red-500" />;
      default:
        return <Minus className="w-4 h-4 text-gray-400" />;
    }
  };

  const getChangeColor = (change: { type: string; value: number }) => {
    switch (change.type) {
      case 'up':
        return 'text-green-500';
      case 'down':
        return 'text-red-500';
      default:
        return 'text-gray-400';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  const topPerformers = companies.slice(0, 3);
  const allCompanies = companies;

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Leaderboard</h1>
        <p className="text-gray-600">See how your team ranks against other companies</p>
      </motion.div>

      {/* Top Performers Section */}
      <motion.div
        className="bg-yellow-50 rounded-2xl p-8 border border-yellow-200"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        <div className="text-center mb-8">
          <div className="w-12 h-12 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Trophy className="w-6 h-6 text-yellow-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Top Performers</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {topPerformers.map((company, index) => {
            const rankChange = getRankChange(index);
            const mockData = {
              teamMembers: [25, 18, 22][index] || 20,
              achievements: [2, 1, 1][index] || 0
            };
            
            return (
              <motion.div
                key={company.id}
                className={`p-6 rounded-xl border ${
                  index === 0 
                    ? 'bg-white border-yellow-300 shadow-lg' 
                    : 'bg-white border-gray-200'
                }`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.2 + index * 0.1 }}
              >
                <div className="text-center">
                  <img 
                    src="/eisw.jpeg" 
                    alt="CISW Logo" 
                    className="w-16 h-16 object-contain rounded-xl mx-auto mb-4"
                  />
                  
                  <h3 className="text-lg font-bold text-gray-900 mb-2">{company.name}</h3>
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center justify-center space-x-2">
                      <Users className="w-4 h-4 text-gray-600" />
                      <span className="text-sm text-gray-600">{mockData.teamMembers}</span>
                    </div>
                    <div className="flex items-center justify-center space-x-2">
                      <Flame className="w-4 h-4 text-gray-600" />
                      <span className="text-sm text-gray-600">{company.total_calories} calories</span>
                    </div>
                    <div className="flex items-center justify-center space-x-2">
                      <Award className="w-4 h-4 text-gray-600" />
                      <span className="text-sm text-gray-600">{mockData.achievements} achievements</span>
                    </div>
                  </div>
                  
                  <p className="text-2xl font-bold text-orange-600 mb-2">{company.total_points}</p>
                </div>
              </motion.div>
            );
          })}
        </div>
      </motion.div>

      {/* Complete Leaderboard Section */}
      <motion.div
        className="bg-white rounded-xl shadow-sm border border-gray-100"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
      >
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">Complete Leaderboard</h2>
            <div className="bg-gray-100 px-3 py-1 rounded-full text-sm font-medium text-gray-700">
              {allCompanies.length} Teams
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="space-y-4">
            {allCompanies.map((company, index) => {
              const rankChange = getRankChange(index);
              const mockData = {
                teamMembers: [25, 18, 22, 20, 15][index] || 20,
                achievements: [2, 1, 1, 0, 0][index] || 0
              };
              
              return (
                <motion.div
                  key={company.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                >
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center justify-center w-10 h-10 bg-white rounded-lg shadow-sm">
                      {getRankIcon(index)}
                    </div>
                    
                    <img 
                      src="/eisw.jpeg" 
                      alt="CISW Logo" 
                      className="w-8 h-8 object-contain rounded-lg"
                    />
                    
                    <div>
                      <h3 className="font-semibold text-gray-900">{company.name}</h3>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <div className="flex items-center space-x-1">
                          <Users className="w-3 h-3" />
                          <span>{mockData.teamMembers}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Flame className="w-3 h-3" />
                          <span>{company.total_calories} cal</span>
                        </div>
                        {mockData.achievements > 0 && (
                          <div className="flex items-center space-x-1">
                            <Award className="w-3 h-3" />
                            <span>{mockData.achievements}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <p className="text-lg font-bold text-gray-900">{company.total_points}</p>
                    </div>
                    
                    <div className="flex items-center space-x-1">
                      {getChangeIcon(rankChange)}
                      <span className={`text-sm font-medium ${getChangeColor(rankChange)}`}>
                        {rankChange.type === 'up' ? `+${rankChange.value}` : 
                         rankChange.type === 'down' ? `-${rankChange.value}` : '-'}
                      </span>
                    </div>
                    
                    {/* Preview button hidden */}
                    {/* {index === 3 && (
                      <button className="px-3 py-1 bg-gray-200 text-gray-700 rounded text-sm font-medium hover:bg-gray-300 transition-colors">
                        Preview
                      </button>
                    )} */}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </motion.div>

      {companies.length === 0 && (
        <motion.div 
          className="text-center py-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <Trophy className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-600 mb-2">No participants yet</h3>
          <p className="text-gray-500">Companies will appear here once they start participating</p>
        </motion.div>
      )}
    </div>
  );
}