import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Task, Upload } from '../types';
import { UploadModal } from './UploadModal';
import { CompanyProfile } from './CompanyProfile';
import { CompanyTasks } from './CompanyTasks';
import { CompanyProgress } from './CompanyProgress';
import { Scoreboard } from './Scoreboard';
import { motion } from 'framer-motion';
import { 
  Home, 
  User, 
  CheckSquare, 
  TrendingUp, 
  Trophy, 
  Users, 
  Flame, 
  Target, 
  Calendar,
  ArrowUpRight,
  LogOut,
  Settings,
  HelpCircle,
  Menu,
  X
} from 'lucide-react';
import toast from 'react-hot-toast';

type DashboardSection = 'dashboard' | 'profile' | 'tasks' | 'progress' | 'leaderboard';

export function CompanyDashboard() {
  const { company, refreshCompany, isAdmin } = useAuth();
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState<DashboardSection>('dashboard');
  const [tasks, setTasks] = useState<Task[]>([]);
  const [uploads, setUploads] = useState<Upload[]>([]);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [companyRank, setCompanyRank] = useState<number>(2);
  const [teamSize, setTeamSize] = useState<number>(0);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    fetchTasks();
    fetchCompanyRank();
    fetchTeamSize();
    
    // Refresh team size every 30 seconds to simulate real-time updates
    const interval = setInterval(() => {
      fetchTeamSize();
    }, 30000);
    
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    fetchUploads();
  }, [company]);

  const fetchTasks = async () => {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .order('day', { ascending: true });

      if (error) throw error;
      setTasks(data || []);
    } catch (error) {
      toast.error('Failed to fetch tasks');
    } finally {
      setLoading(false);
    }
  };

  const fetchUploads = async () => {
    if (!company) return;

    try {
      const { data, error } = await supabase
        .from('uploads')
        .select('*')
        .eq('company_id', company.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setUploads(data || []);
    } catch (error) {
      toast.error('Failed to fetch uploads');
    }
  };

  const fetchCompanyRank = async () => {
    if (!company) return;

    try {
      const { data, error } = await supabase
        .from('companies')
        .select('id, total_points')
        .order('total_points', { ascending: false });

      if (error) throw error;
      
      const rank = data?.findIndex(c => c.id === company.id) + 1;
      setCompanyRank(rank || 1);
    } catch (error) {
      console.error('Failed to fetch company rank');
    }
  };

  const fetchTeamSize = async () => {
    try {
      const { count, error } = await supabase
        .from('companies')
        .select('*', { count: 'exact', head: true });

      if (error) throw error;
      setTeamSize(count || 0);
    } catch (error) {
      console.error('Failed to fetch team size');
      setTeamSize(0);
    }
  };

  const handleUploadSuccess = () => {
    fetchUploads();
    refreshCompany();
    setShowUploadModal(false);
    toast.success('Upload submitted for review!');
  };

  const getTaskUpload = (taskId: string) => {
    return uploads.find(upload => upload.task_id === taskId);
  };

  const getTodaysTasks = () => {
    const today = new Date().getDay() + 1; // Adjust based on your day numbering
    return tasks.filter(task => task.day === today);
  };

  const getTodaysCalories = () => {
    const todaysTasks = getTodaysTasks();
    return todaysTasks.reduce((sum, task) => sum + task.target_calories, 0);
  };

  const getTodaysProgress = () => {
    const todaysTasks = getTodaysTasks();
    const completedTasks = todaysTasks.filter(task => {
      const upload = getTaskUpload(task.id);
      return upload && upload.status === 'approved';
    });
    return todaysTasks.length > 0 ? (completedTasks.length / todaysTasks.length) * 100 : 0;
  };

  const navigationItems = [
    { id: 'dashboard' as DashboardSection, label: 'Dashboard', icon: Home },
    { id: 'profile' as DashboardSection, label: 'Company Profile', icon: User },
    { id: 'tasks' as DashboardSection, label: 'Tasks', icon: CheckSquare, hasNotification: true },
    { id: 'progress' as DashboardSection, label: 'Progress', icon: TrendingUp },
    { id: 'leaderboard' as DashboardSection, label: 'Leaderboard', icon: Trophy },
  ];

  const handleSignOut = () => {
    navigate('/signout');
  };

  const handleAdminSwitch = () => {
    navigate('/admin');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex w-full">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      
      {/* Sidebar */}
      <div className={`
        fixed lg:static inset-y-0 left-0 z-50 w-64 bg-white shadow-lg flex flex-col
        lg:transform-none transform transition-transform duration-300 ease-in-out
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Logo and Company Info */}
        <div className="p-6 border-b border-gray-100">
          {/* Mobile Close Button */}
          <button
            onClick={() => setSidebarOpen(false)}
            className="lg:hidden absolute top-4 right-4 p-2 rounded-md text-gray-400 hover:text-gray-600 hover:bg-gray-100"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="flex items-center space-x-3 mb-4">
            <img 
              src="/eisw.jpeg" 
              alt="CISW Logo" 
              className="w-12 h-12 object-contain"
            />
            <div>
              <h1 className="text-lg font-bold text-gray-900">Curaçao Sports Week</h1>
              <p className="text-sm text-gray-600">Company Dashboard</p>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span className="text-sm font-medium text-gray-900">{company?.name}</span>
            </div>
            <div className="flex items-center justify-between text-sm text-gray-600">
              <span>Rank #{companyRank}</span>
              <span className="font-semibold">{company?.total_points || 0} pts</span>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4">
          <ul className="space-y-2">
            {navigationItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              
              return (
                <li key={item.id}>
                  <button
                    onClick={() => {
                      setActiveSection(item.id);
                      setSidebarOpen(false); // Close sidebar on mobile after navigation
                    }}
                    className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                      isActive
                        ? 'bg-blue-500 text-white'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span>{item.label}</span>
                    {item.hasNotification && (
                      <div className="w-2 h-2 bg-blue-500 rounded-full ml-auto"></div>
                    )}
                  </button>
                </li>
              );
            })}
          </ul>
        </nav>

        {/* Bottom Actions */}
        <div className="p-4 border-t border-gray-100 space-y-2">
          {isAdmin && (
            <button
              onClick={handleAdminSwitch}
              className="w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <Settings className="w-5 h-5" />
              <span>Switch to Admin</span>
            </button>
          )}
          <button
            onClick={handleSignOut}
            className="w-full flex items-center space-x-3 px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col w-full">
        {/* Mobile Header */}
        <div className="lg:hidden bg-white shadow-sm border-b border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setSidebarOpen(true)}
              className="p-2 rounded-md text-gray-400 hover:text-gray-600 hover:bg-gray-100"
            >
              <Menu className="w-6 h-6" />
            </button>
            <h1 className="text-xl font-bold text-gray-900">
              {activeSection === 'dashboard' && 'Dashboard'}
              {activeSection === 'profile' && 'Company Profile'}
              {activeSection === 'tasks' && 'Tasks'}
              {activeSection === 'progress' && 'Progress'}
              {activeSection === 'leaderboard' && 'Leaderboard'}
            </h1>
            <div className="w-10"></div> {/* Spacer for centering */}
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 p-6 w-full">
          {/* Page Title - Desktop Only */}
          <div className="hidden lg:block mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              {activeSection === 'dashboard' && 'Dashboard'}
              {activeSection === 'profile' && 'Company Profile'}
              {activeSection === 'tasks' && 'Tasks'}
              {activeSection === 'progress' && 'Progress'}
              {activeSection === 'leaderboard' && 'Leaderboard'}
            </h1>
            <p className="text-gray-600">
              {activeSection === 'dashboard' && 'Track your team\'s progress and today\'s challenges'}
              {activeSection === 'profile' && 'Manage your company information and settings'}
              {activeSection === 'tasks' && 'View and complete daily challenges'}
              {activeSection === 'progress' && 'Track your team\'s achievements and statistics'}
              {activeSection === 'leaderboard' && 'See how your team ranks against other companies'}
            </p>
          </div>

          {activeSection === 'dashboard' && (
            <div className="space-y-6">
              {/* Welcome Banner */}
              <motion.div 
                className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-4 md:p-6 border border-blue-100"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div className="flex items-center space-x-4">
                    <img 
                      src="/eisw.jpeg" 
                      alt="CISW Logo" 
                      className="w-12 h-12 object-contain rounded-lg"
                    />
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900">Welcome back, {company?.name}!</h2>
                      <p className="text-gray-600 mt-1 flex items-center space-x-2">
                        <span>Ready for another day of challenges? Let's keep the momentum going!</span>
                        <Trophy className="w-4 h-4 text-yellow-500" />
                        <span className="text-lg">💪</span>
                      </p>
                    </div>
                  </div>
                  <div className="bg-gray-100 px-3 py-1 rounded-full text-sm font-medium text-gray-700">
                    #{companyRank} Overall
                  </div>
                </div>
              </motion.div>

              {/* Key Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* Total Points */}
                <motion.div 
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.1 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                      <Trophy className="w-5 h-5 text-yellow-600" />
                    </div>
                    <ArrowUpRight className="w-4 h-4 text-gray-400" />
                  </div>
                  <h3 className="text-sm font-medium text-gray-600 mb-1">TOTAL POINTS</h3>
                  <p className="text-3xl font-bold text-yellow-600 mb-1">{company?.total_points || 0}</p>
                  <p className="text-sm text-gray-500">Earned across all challenges</p>
                </motion.div>

                {/* Team Size */}
                <motion.div 
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Users className="w-5 h-5 text-blue-600" />
                    </div>
                    <ArrowUpRight className="w-4 h-4 text-gray-400" />
                  </div>
                  <h3 className="text-sm font-medium text-gray-600 mb-1">TEAM SIZE</h3>
                  <p className="text-3xl font-bold text-blue-600 mb-1">{teamSize}</p>
                  <p className="text-sm text-gray-500">Active participants</p>
                </motion.div>

                {/* Total Calories */}
                <motion.div 
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.3 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                      <Flame className="w-5 h-5 text-orange-600" />
                    </div>
                    <ArrowUpRight className="w-4 h-4 text-gray-400" />
                  </div>
                  <h3 className="text-sm font-medium text-gray-600 mb-1">TOTAL CALORIES</h3>
                  <p className="text-3xl font-bold text-orange-600 mb-1">{company?.total_calories || 0}</p>
                  <p className="text-sm text-gray-500">Burned by your team</p>
                </motion.div>

                {/* Today's Goal */}
                <motion.div 
                  className="bg-white rounded-xl p-6 shadow-sm border border-gray-100"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.4 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <Target className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="text-sm font-medium text-green-600">
                      {Math.round(getTodaysProgress())}%
                    </div>
                  </div>
                  <h3 className="text-sm font-medium text-gray-600 mb-1">TODAY'S GOAL</h3>
                  <p className="text-3xl font-bold text-green-600 mb-2">{getTodaysCalories()}</p>
                  <p className="text-sm text-gray-500 mb-3">of {getTodaysCalories()} calories</p>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-500 h-2 rounded-full transition-all duration-500"
                      style={{ width: `${getTodaysProgress()}%` }}
                    ></div>
                  </div>
                </motion.div>
              </div>

              {/* Today's Challenges */}
              <motion.div 
                className="bg-white rounded-xl shadow-sm border border-gray-100"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.5 }}
              >
                <div className="p-6 border-b border-gray-100">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Calendar className="w-4 h-4 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">Today's Challenges</h3>
                        <p className="text-sm text-gray-600">Complete tasks to earn points</p>
                      </div>
                    </div>
                    <div className="bg-gray-100 px-3 py-1 rounded-full text-sm font-medium text-gray-700">
                      {getTodaysTasks().length} Active
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  <div className="space-y-4">
                    {getTodaysTasks().map((task, index) => {
                      const upload = getTaskUpload(task.id);
                      const isCompleted = upload && upload.status === 'approved';
                      const colors = ['bg-green-500', 'bg-yellow-500', 'bg-blue-500'];
                      
                      return (
                        <motion.div
                          key={task.id}
                          className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.4, delay: index * 0.1 }}
                        >
                          <div className="flex items-center space-x-4">
                            <div className={`w-3 h-3 rounded-full ${colors[index % colors.length]}`}></div>
                            <div>
                              <p className="font-medium text-gray-900">{task.title}</p>
                              <p className="text-sm text-gray-600">{task.description}</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-3">
                            {/* Preview button hidden */}
                            {/* {!isCompleted && (
                              <button
                                onClick={() => {
                                  if (!company) {
                                    toast.error('Your company profile is still loading. Please try again.');
                                    return;
                                  }
                                  setSelectedTask(task);
                                  setShowUploadModal(true);
                                }}
                                className="px-3 py-1 bg-gray-200 text-gray-700 rounded text-sm font-medium hover:bg-gray-300 transition-colors"
                              >
                                Preview
                              </button>
                            )} */}
                            <span className="text-sm font-medium text-gray-900">
                              {task.target_calories} pts
                            </span>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                </div>
              </motion.div>
            </div>
          )}

          {activeSection === 'profile' && (
            <CompanyProfile />
          )}
          {activeSection === 'tasks' && (
            <CompanyTasks />
          )}
          {activeSection === 'progress' && (
            <CompanyProgress />
          )}
          {activeSection === 'leaderboard' && (
            <Scoreboard />
          )}
        </div>
      </div>

      {/* Help Button */}
      <button className="fixed bottom-6 right-6 w-12 h-12 bg-blue-500 text-white rounded-full shadow-lg hover:bg-blue-600 transition-colors flex items-center justify-center">
        <HelpCircle className="w-6 h-6" />
      </button>

      {/* Upload Modal */}
      {company && showUploadModal && selectedTask && (
        <UploadModal
          task={selectedTask}
          companyId={company.id}
          onClose={() => setShowUploadModal(false)}
          onSuccess={handleUploadSuccess}
        />
      )}
    </div>
  );
}
