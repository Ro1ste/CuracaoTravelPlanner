import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { LogOut, Trophy, Target } from 'lucide-react';
import { motion } from 'framer-motion';

interface LayoutProps {
  children: React.ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const { user, company, isAdmin } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = () => {
    navigate('/signout');
  };

  if (!user) return <>{children}</>;

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-blue-100">
      <header className="bg-white shadow-sm border-b border-sky-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <motion.div 
              className="flex items-center space-x-3"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="w-10 h-10 bg-gradient-to-br from-sky-500 to-blue-600 rounded-lg flex items-center justify-center">
                <Trophy className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Curaçao International Sportsweek</h1>
                <p className="text-sm text-sky-600 font-medium">{company?.name ?? ''}</p>
              </div>
            </motion.div>

            <div className="flex items-center space-x-6">
              <motion.div 
                className="flex items-center space-x-4 text-sm"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <div className="flex items-center space-x-2 bg-gradient-to-r from-orange-50 to-orange-100 px-3 py-2 rounded-lg">
                  <Trophy className="w-4 h-4 text-orange-600" />
                  <span className="font-semibold text-orange-800">{company?.total_points ?? 0} points</span>
                </div>
                <div className="flex items-center space-x-2 bg-gradient-to-r from-green-50 to-green-100 px-3 py-2 rounded-lg">
                  <Target className="w-4 h-4 text-green-600" />
                  <span className="font-semibold text-green-800">{company?.total_calories ?? 0} calories</span>
                </div>
              </motion.div>

              {isAdmin && (
                <motion.button
                  onClick={() => navigate('/admin')}
                  className="text-sm font-medium text-sky-600 hover:text-sky-700"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Admin
                </motion.button>
              )}

              <motion.button
                onClick={handleSignOut}
                className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors duration-200"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm font-medium">Sign Out</span>
              </motion.button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>
    </div>
  );
}