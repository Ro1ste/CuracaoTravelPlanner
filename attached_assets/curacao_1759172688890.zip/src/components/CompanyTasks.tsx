import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Task, Upload } from '../types';
import { UploadModal } from './UploadModal';
import { motion } from 'framer-motion';
import { FileText, Download, Camera, Video, ArrowUp } from 'lucide-react';
import toast from 'react-hot-toast';

export function CompanyTasks() {
  const { company, refreshCompany } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [uploads, setUploads] = useState<Upload[]>([]);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'active' | 'submitted'>('active');

  useEffect(() => {
    fetchTasks();
  }, []);

  useEffect(() => {
    fetchUploads();
  }, [company]);

  const fetchTasks = async () => {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .order('day', { ascending: true });

      if (error) throw error;
      setTasks(data || []);
    } catch (error) {
      toast.error('Failed to fetch tasks');
    } finally {
      setLoading(false);
    }
  };

  const fetchUploads = async () => {
    if (!company) return;

    try {
      const { data, error } = await supabase
        .from('uploads')
        .select('*')
        .eq('company_id', company.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setUploads(data || []);
    } catch (error) {
      toast.error('Failed to fetch uploads');
    }
  };

  const handleUploadSuccess = () => {
    fetchUploads();
    refreshCompany();
    setShowUploadModal(false);
    toast.success('Upload submitted for review!');
  };

  const getTaskUpload = (taskId: string) => {
    return uploads.find(upload => upload.task_id === taskId);
  };


  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'text-green-600';
      case 'rejected':
        return 'text-red-600';
      default:
        return 'text-yellow-600';
    }
  };

  const getActiveTasks = () => {
    return tasks.filter(task => {
      const upload = getTaskUpload(task.id);
      return !upload || upload.status === 'pending';
    });
  };

  const getSubmittedTasks = () => {
    return tasks.filter(task => {
      const upload = getTaskUpload(task.id);
      return upload && upload.status !== 'pending';
    });
  };

  const getTotalEarnedPoints = () => {
    return uploads
      .filter(upload => upload.status === 'approved')
      .reduce((sum, upload) => {
        const task = tasks.find(t => t.id === upload.task_id);
        return sum + (task?.target_calories || 0);
      }, 0);
  };

  const getTotalPossiblePoints = () => {
    return tasks.reduce((sum, task) => sum + task.target_calories, 0);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Tasks</h1>
        <p className="text-gray-600">Complete daily challenges and earn points for your team</p>
      </motion.div>

      {/* Challenge Progress Card */}
      <motion.div
        className="bg-green-50 rounded-xl p-6 border border-green-200"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        <h2 className="text-lg font-semibold text-gray-900 mb-2">Challenge Progress</h2>
        <p className="text-gray-600 mb-4">Complete tasks to earn points for your team</p>
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
              <div 
                className="bg-blue-500 h-3 rounded-full transition-all duration-500"
                style={{ width: `${(getTotalEarnedPoints() / getTotalPossiblePoints()) * 100}%` }}
              ></div>
            </div>
          </div>
          <div className="ml-4 text-right">
            <span className="text-green-600 font-bold text-lg">{getTotalEarnedPoints()}</span>
            <span className="text-gray-600"> / {getTotalPossiblePoints()} points</span>
          </div>
        </div>
      </motion.div>

      {/* Daily Tasks Document */}
      <motion.div
        className="bg-white rounded-xl shadow-sm border border-gray-100 p-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
          <FileText className="w-5 h-5" />
          <span>Weekly Tasks Documents</span>
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {tasks.map((task, index) => (
            <div key={task.id} className="bg-blue-50 rounded-lg p-4 border border-blue-200">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900">Day {task.day} - {task.title}</h3>
                  <p className="text-sm text-gray-600 mt-1">{task.description}</p>
                  <p className="text-xs text-blue-600 mt-1">Target: {task.target_calories} calories</p>
                </div>
                <button 
                  onClick={() => {
                    if (task.document_url) {
                      window.open(task.document_url, '_blank');
                    } else {
                      // Create a sample document URL for demonstration
                      const sampleDocUrl = `https://example.com/day-${task.day}-tasks.pdf`;
                      window.open(sampleDocUrl, '_blank');
                    }
                  }}
                  className="px-3 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors flex items-center space-x-2"
                >
                  <Download className="w-4 h-4" />
                  <span>Download</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Tasks Tabs */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('active')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'active'
                  ? 'border-gray-300 text-gray-900'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Active Tasks ({getActiveTasks().length})
            </button>
            <button
              onClick={() => setActiveTab('submitted')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'submitted'
                  ? 'border-gray-300 text-gray-900'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Submitted ({getSubmittedTasks().length})
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'active' ? (
            <div className="space-y-4">
              {getActiveTasks().map((task, index) => {
                const isVideo = task.title.toLowerCase().includes('video');
                
                return (
                  <motion.div
                    key={task.id}
                    className="bg-white border border-gray-200 rounded-lg p-6"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        {isVideo ? (
                          <Video className="w-5 h-5 text-blue-600" />
                        ) : (
                          <Camera className="w-5 h-5 text-blue-600" />
                        )}
                        <div>
                          <h3 className="font-semibold text-gray-900">{task.title}</h3>
                          <p className="text-sm text-gray-600 mt-1">{task.description}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-sm font-medium text-gray-900">{task.target_calories} pts</span>
                        <p className="text-xs text-gray-500">Due: Today, 12:00 PM</p>
                      </div>
                    </div>

                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                      <ArrowUp className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-600 mb-4">Upload your {isVideo ? 'video' : 'photo'} (JPG, PNG)</p>
                      <button
                        onClick={() => {
                          if (!company) {
                            toast.error('Your company profile is still loading. Please try again.');
                            return;
                          }
                          setSelectedTask(task);
                          setShowUploadModal(true);
                        }}
                        className="px-4 py-2 bg-blue-500 text-white rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors"
                      >
                        Choose File
                      </button>
                    </div>

                    <div className="mt-4 text-center">
                      {/* Preview button hidden */}
                      {/* <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors">
                        Preview
                      </button> */}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          ) : (
            <div className="space-y-4">
              {getSubmittedTasks().map((task, index) => {
                const upload = getTaskUpload(task.id);
                const isVideo = task.title.toLowerCase().includes('video');
                
                return (
                  <motion.div
                    key={task.id}
                    className="bg-white border border-gray-200 rounded-lg p-6"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        {isVideo ? (
                          <Video className="w-5 h-5 text-blue-600" />
                        ) : (
                          <Camera className="w-5 h-5 text-blue-600" />
                        )}
                        <div>
                          <h3 className="font-semibold text-gray-900">{task.title}</h3>
                          <p className="text-sm text-gray-600 mt-1">{task.description}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className={`text-sm font-medium ${getStatusColor(upload?.status || 'pending')}`}>
                          {upload?.status === 'approved' ? 'Approved' : upload?.status === 'rejected' ? 'Submitted' : 'Submitted'}
                        </span>
                        <p className="text-xs text-gray-500">
                          {upload?.status === 'approved' ? `+${task.target_calories} pts` : `${task.target_calories} pts`}
                        </p>
                      </div>
                    </div>

                    {upload && (
                      <div className="space-y-3">
                        {upload.file_type === 'image' ? (
                          <img
                            src={upload.file_url}
                            alt="Upload"
                            className="w-full h-48 object-cover rounded-lg"
                          />
                        ) : (
                          <video
                            src={upload.file_url}
                            controls
                            className="w-full h-48 object-cover rounded-lg"
                          />
                        )}
                        
                        {upload.status === 'approved' && (
                          <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                            <p className="text-sm text-green-800">Great work! Your submission has been approved.</p>
                          </div>
                        )}
                        
                        {upload.status === 'rejected' && (
                          <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                            <p className="text-sm text-red-800">Admin Feedback: Great healthy choices! Well done team.</p>
                          </div>
                        )}
                      </div>
                    )}

                    <div className="mt-4 text-right">
                      {/* Preview button hidden */}
                      {/* <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors">
                        Preview
                      </button> */}
                    </div>
                  </motion.div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Upload Modal */}
      {company && showUploadModal && selectedTask && (
        <UploadModal
          task={selectedTask}
          companyId={company.id}
          onClose={() => setShowUploadModal(false)}
          onSuccess={handleUploadSuccess}
        />
      )}
    </div>
  );
}
