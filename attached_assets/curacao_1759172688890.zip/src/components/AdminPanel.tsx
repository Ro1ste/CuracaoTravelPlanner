import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Upload, Task, Company } from '../types';
import { motion } from 'framer-motion';
import { TaskForm } from './TaskForm';
import { CheckCircle, XCircle, Eye, Image, Video, Target, Plus, Trophy } from 'lucide-react';
import toast from 'react-hot-toast';

export function AdminPanel() {
  const [uploads, setUploads] = useState<Upload[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [companies, setCompanies] = useState<Company[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedUpload, setSelectedUpload] = useState<Upload | null>(null);
  const [showTaskForm, setShowTaskForm] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [uploadsResult, tasksResult, companiesResult] = await Promise.all([
        supabase.from('uploads').select('*').order('created_at', { ascending: false }),
        supabase.from('tasks').select('*').order('day', { ascending: true }),
        supabase.from('companies').select('*').order('name', { ascending: true })
      ]);

      if (uploadsResult.error) throw uploadsResult.error;
      if (tasksResult.error) throw tasksResult.error;
      if (companiesResult.error) throw companiesResult.error;

      setUploads(uploadsResult.data || []);
      setTasks(tasksResult.data || []);
      setCompanies(companiesResult.data || []);
    } catch (error) {
      toast.error('Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (upload: Upload) => {
    const pointsAwarded = prompt('Enter points to award (default: 100):');
    const points = pointsAwarded ? parseInt(pointsAwarded) : 100;

    try {
      await supabase
        .from('uploads')
        .update({ 
          status: 'approved', 
          points_awarded: points 
        })
        .eq('id', upload.id);

      // Update company points and calories
      const task = tasks.find(t => t.id === upload.task_id);
      await supabase.rpc('update_company_stats', {
        company_id: upload.company_id,
        points_to_add: points,
        calories_to_add: task?.target_calories || 0
      });

      toast.success('Upload approved!');
      fetchData();
    } catch (error) {
      toast.error('Failed to approve upload');
    }
  };

  const handleReject = async (upload: Upload) => {
    try {
      await supabase
        .from('uploads')
        .update({ status: 'rejected' })
        .eq('id', upload.id);

      toast.success('Upload rejected');
      fetchData();
    } catch (error) {
      toast.error('Failed to reject upload');
    }
  };

  const getCompanyName = (companyId: string) => {
    const company = companies.find(c => c.id === companyId);
    return company?.name || 'Unknown Company';
  };

  const getTaskName = (taskId: string) => {
    const task = tasks.find(t => t.id === taskId);
    return task?.title || 'Unknown Task';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Admin Panel</h1>
        <motion.button
          onClick={() => setShowTaskForm(true)}
          className="flex items-center space-x-2 bg-gradient-to-r from-sky-500 to-blue-600 text-white px-4 py-2 rounded-xl font-medium hover:from-sky-600 hover:to-blue-700 transition-all duration-200"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Plus className="w-4 h-4" />
          <span>Add Task</span>
        </motion.button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Pending Uploads</h2>
          <div className="space-y-4">
            {uploads
              .filter(upload => upload.status === 'pending')
              .map((upload, index) => (
                <motion.div
                  key={upload.id}
                  className="bg-white rounded-2xl shadow-lg border border-gray-100 p-6"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-bold text-gray-900">{getCompanyName(upload.company_id)}</h3>
                      <p className="text-gray-600">{getTaskName(upload.task_id)}</p>
                    </div>
                    <div className="flex items-center space-x-1">
                      {upload.file_type === 'image' ? (
                        <Image className="w-5 h-5 text-sky-600" />
                      ) : (
                        <Video className="w-5 h-5 text-purple-600" />
                      )}
                    </div>
                  </div>

                  <div className="flex space-x-3">
                    <button
                      onClick={() => window.open(upload.file_url, '_blank')}
                      className="flex-1 flex items-center justify-center space-x-2 py-2 px-4 border border-sky-300 text-sky-600 rounded-lg hover:bg-sky-50 transition-colors duration-200"
                    >
                      <Eye className="w-4 h-4" />
                      <span>View</span>
                    </button>
                    <button
                      onClick={() => handleApprove(upload)}
                      className="flex-1 flex items-center justify-center space-x-2 py-2 px-4 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors duration-200"
                    >
                      <CheckCircle className="w-4 h-4" />
                      <span>Approve</span>
                    </button>
                    <button
                      onClick={() => handleReject(upload)}
                      className="flex-1 flex items-center justify-center space-x-2 py-2 px-4 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors duration-200"
                    >
                      <XCircle className="w-4 h-4" />
                      <span>Reject</span>
                    </button>
                  </div>
                </motion.div>
              ))}

            {uploads.filter(upload => upload.status === 'pending').length === 0 && (
              <div className="text-center py-8">
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-3" />
                <p className="text-gray-600">No pending uploads</p>
              </div>
            )}
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Leaderboard</h2>
          <div className="space-y-3">
            {companies.slice(0, 10).map((company, index) => (
              <motion.div
                key={company.id}
                className="bg-white rounded-xl shadow-md border border-gray-100 p-4"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gradient-to-br from-sky-500 to-blue-600 rounded-lg flex items-center justify-center text-white font-bold">
                      {index + 1}
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{company.name}</h3>
                      <p className="text-sm text-gray-600">{company.contact_name} {company.contact_last_name}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4 text-sm">
                    <div className="flex items-center space-x-1">
                      <Trophy className="w-4 h-4 text-orange-600" />
                      <span className="font-semibold">{company.total_points}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Target className="w-4 h-4 text-green-600" />
                      <span className="font-semibold">{company.total_calories}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {showTaskForm && (
        <TaskForm
          onClose={() => setShowTaskForm(false)}
          onSuccess={() => {
            setShowTaskForm(false);
            fetchData();
          }}
        />
      )}
    </div>
  );
}