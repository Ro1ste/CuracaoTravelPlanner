# Curaçao International Sportsweek Platform

A comprehensive sports tracking platform for companies participating in Curaçao International Sportsweek.

## Features

- **Company Registration**: Automated account creation with email and password
- **Task Management**: Daily tasks with document links and calorie targets
- **File Uploads**: Support for images and videos as proof of completion
- **Points System**: Admin approval system with customizable points
- **Public Scoreboard**: Live rankings accessible to everyone
- **Real-time Updates**: Live data synchronization across all components

## Setup Instructions

1. **Supabase Setup**: Click the "Connect to Supabase" button in the top right to set up your database
2. **Environment Variables**: The required environment variables will be automatically configured
3. **Database Schema**: The database schema will be automatically created with the migration files

## Routes

- `/` - Main dashboard (requires authentication)
- `/scoreboard` - Public scoreboard (no authentication required)
- `/admin` - Admin panel for approving uploads and managing tasks

## Usage

### For Companies
1. Register your company using the registration form
2. Log in with the generated credentials
3. View daily tasks and documents
4. Upload proof (images/videos) of task completion
5. Track your points and calories in real-time

### For Administrators
1. Access the admin panel at `/admin`
2. Review and approve/reject uploaded content
3. Award points for approved submissions
4. Create new tasks with calorie targets

### Public Access
- Anyone can view the live scoreboard at `/scoreboard`
- Share this link publicly for community engagement

## Technologies Used

- **Frontend**: React, TypeScript, Tailwind CSS, Framer Motion
- **Backend**: Supabase (PostgreSQL, Authentication, Storage)
- **File Storage**: Supabase Storage for images and videos
- **Real-time**: Supabase real-time subscriptions
- **Deployment**: Vite build system