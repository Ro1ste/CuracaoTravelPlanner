-- Enhanced company features migration
-- Add support for company logos and participant tracking

-- Add logo_url column to companies table
ALTER TABLE companies 
ADD COLUMN IF NOT EXISTS logo_url text,
ADD COLUMN IF NOT EXISTS participant_count integer DEFAULT 0;

-- Add comment for documentation
COMMENT ON COLUMN companies.logo_url IS 'URL to company logo image';
COMMENT ON COLUMN companies.participant_count IS 'Number of participants in the company';

-- Update the company stats function to handle participant count
CREATE OR REPLACE FUNCTION update_company_stats(
  company_id uuid,
  points_to_add integer,
  calories_to_add integer,
  participant_count integer DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE companies 
  SET 
    total_points = total_points + points_to_add,
    total_calories = total_calories + calories_to_add,
    participant_count = COALESCE(participant_count, companies.participant_count)
  WHERE id = company_id;
END;
$$;

-- Add policy for companies to update their own participant count
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'companies' AND policyname = 'Companies can update participant count'
  ) THEN
    CREATE POLICY "Companies can update participant count"
      ON public.companies
      FOR UPDATE
      TO authenticated
      USING (id = auth.uid())
      WITH CHECK (id = auth.uid());
  END IF;
END $$;

-- Add policy for companies to update their logo
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'companies' AND policyname = 'Companies can update logo'
  ) THEN
    CREATE POLICY "Companies can update logo"
      ON public.companies
      FOR UPDATE
      TO authenticated
      USING (id = auth.uid())
      WITH CHECK (id = auth.uid());
  END IF;
END $$;

-- Create storage bucket for company logos if it doesn't exist
INSERT INTO storage.buckets (id, name, public) 
VALUES ('company-logos', 'company-logos', true)
ON CONFLICT (id) DO NOTHING;

-- Create storage policies for company logos
CREATE POLICY "Companies can upload their own logos"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'company-logos' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Companies can update their own logos"
  ON storage.objects
  FOR UPDATE
  TO authenticated
  USING (bucket_id = 'company-logos' AND auth.uid()::text = (storage.foldername(name))[1])
  WITH CHECK (bucket_id = 'company-logos' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Anyone can view company logos"
  ON storage.objects
  FOR SELECT
  TO authenticated
  USING (bucket_id = 'company-logos');

-- Add real-time publication for companies table
ALTER PUBLICATION supabase_realtime ADD TABLE companies;

-- Add real-time publication for uploads table  
ALTER PUBLICATION supabase_realtime ADD TABLE uploads;
