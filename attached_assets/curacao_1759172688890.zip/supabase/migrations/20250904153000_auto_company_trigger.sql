-- Auto-create companies row on new user signup and allow safe self-insert

-- Function to create a company record for every new auth user using metadata
CREATE OR REPLACE FUNCTION public.create_company_for_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.companies (
    id,
    name,
    contact_name,
    contact_last_name,
    email,
    phone
  ) VALUES (
    NEW.id,
    COALESCE((NEW.raw_user_meta_data->>'name')::text, ''),
    COALESCE((NEW.raw_user_meta_data->>'contact_name')::text, ''),
    COALESCE((NEW.raw_user_meta_data->>'contact_last_name')::text, ''),
    COALESCE(NEW.email, ''),
    COALESCE((NEW.raw_user_meta_data->>'phone')::text, '')
  )
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$;

-- Recreate trigger that fires after an auth user is created
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_trigger
    WHERE tgname = 'on_auth_user_created_create_company'
  ) THEN
    DROP TRIGGER on_auth_user_created_create_company ON auth.users;
  END IF;
END $$;

CREATE TRIGGER on_auth_user_created_create_company
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.create_company_for_new_user();

-- Optional: allow authenticated users to self-insert their own companies row (not required with trigger)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'companies'
      AND policyname = 'Companies can self-insert own row'
  ) THEN
    CREATE POLICY "Companies can self-insert own row"
      ON public.companies
      FOR INSERT
      TO authenticated
      WITH CHECK (id = auth.uid());
  END IF;
END $$;
