-- Development-friendly RLS policies to unblock admin actions from the client
-- NOTE: These grant broader access to authenticated users. Tighten before production.

-- Allow all authenticated users to view companies (needed for leaderboard/admin panel)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'companies' AND policyname = 'Anyone authenticated can view companies'
  ) THEN
    CREATE POLICY "Anyone authenticated can view companies"
      ON public.companies
      FOR SELECT
      TO authenticated
      USING (true);
  END IF;
END $$;

-- Allow all authenticated users to create and edit tasks (admin convenience)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'tasks' AND policyname = 'Authenticated can insert tasks'
  ) THEN
    CREATE POLICY "Authenticated can insert tasks"
      ON public.tasks
      FOR INSERT
      TO authenticated
      WITH CHECK (true);
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'tasks' AND policyname = 'Authenticated can update tasks'
  ) THEN
    CREATE POLICY "Authenticated can update tasks"
      ON public.tasks
      FOR UPDATE
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END $$;

-- Allow all authenticated users to update uploads (admin approval from client)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'uploads' AND policyname = 'Authenticated can update uploads'
  ) THEN
    CREATE POLICY "Authenticated can update uploads"
      ON public.uploads
      FOR UPDATE
      TO authenticated
      USING (true)
      WITH CHECK (true);
  END IF;
END $$;


