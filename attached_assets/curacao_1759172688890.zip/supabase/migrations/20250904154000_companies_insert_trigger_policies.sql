-- Ensure the auth signup trigger can insert into companies under RLS

-- Allow INSERTs by the table owner/superuser role if it exists (commonly 'postgres')
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'postgres') AND NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'companies' AND policyname = 'Trigger can insert companies (postgres)'
  ) THEN
    CREATE POLICY "Trigger can insert companies (postgres)"
      ON public.companies
      FOR INSERT
      TO postgres
      WITH CHECK (true);
  END IF;
END $$;

-- Allow INSERTs by Supabase admin role if it exists
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'supabase_admin') AND NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'companies' AND policyname = 'Trigger can insert companies (supabase_admin)'
  ) THEN
    CREATE POLICY "Trigger can insert companies (supabase_admin)"
      ON public.companies
      FOR INSERT
      TO supabase_admin
      WITH CHECK (true);
  END IF;
END $$;

-- Allow INSERTs by Supabase auth admin role if it exists
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'supabase_auth_admin') AND NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE schemaname = 'public' AND tablename = 'companies' AND policyname = 'Trigger can insert companies (supabase_auth_admin)'
  ) THEN
    CREATE POLICY "Trigger can insert companies (supabase_auth_admin)"
      ON public.companies
      FOR INSERT
      TO supabase_auth_admin
      WITH CHECK (true);
  END IF;
END $$;


