/*
  # Create initial schema for Curaçao International Sportsweek

  1. New Tables
    - `companies`
      - `id` (uuid, primary key) - matches auth.users.id
      - `name` (text) - company name
      - `contact_name` (text) - contact person first name
      - `contact_last_name` (text) - contact person last name
      - `email` (text, unique) - company email
      - `phone` (text) - company phone number
      - `total_points` (integer) - running total of points earned
      - `total_calories` (integer) - running total of calories burned
      - `created_at` (timestamptz) - registration timestamp

    - `tasks`
      - `id` (uuid, primary key)
      - `title` (text) - task title
      - `description` (text) - task description
      - `document_url` (text, optional) - link to task document
      - `day` (integer) - day number (1-7)
      - `target_calories` (integer) - calories target for this task
      - `created_at` (timestamptz)

    - `uploads`
      - `id` (uuid, primary key)
      - `company_id` (uuid, foreign key) - references companies.id
      - `task_id` (uuid, foreign key) - references tasks.id
      - `file_url` (text) - URL to uploaded file
      - `file_type` (text) - 'image' or 'video'
      - `status` (text) - 'pending', 'approved', or 'rejected'
      - `points_awarded` (integer, optional) - points given when approved
      - `created_at` (timestamptz)

    - `daily_calories`
      - `id` (uuid, primary key)
      - `day` (integer) - day number
      - `target_calories` (integer) - daily calorie target
      - `date` (date) - specific date
      - `created_at` (timestamptz)

  2. Storage
    - Create storage bucket for file uploads

  3. Security
    - Enable RLS on all tables
    - Add policies for authenticated users and admin access

  4. Functions
    - Create function to update company stats when uploads are approved
*/

-- Create companies table
CREATE TABLE IF NOT EXISTS companies (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  contact_name text NOT NULL,
  contact_last_name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text NOT NULL,
  total_points integer DEFAULT 0,
  total_calories integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create tasks table
CREATE TABLE IF NOT EXISTS tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  document_url text,
  day integer NOT NULL CHECK (day >= 1 AND day <= 7),
  target_calories integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create uploads table
CREATE TABLE IF NOT EXISTS uploads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  task_id uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  file_url text NOT NULL,
  file_type text NOT NULL CHECK (file_type IN ('image', 'video')),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  points_awarded integer,
  created_at timestamptz DEFAULT now()
);

-- Create daily_calories table
CREATE TABLE IF NOT EXISTS daily_calories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  day integer NOT NULL CHECK (day >= 1 AND day <= 7),
  target_calories integer NOT NULL DEFAULT 0,
  date date NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(day, date)
);

-- Enable RLS
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE uploads ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_calories ENABLE ROW LEVEL SECURITY;

-- Create policies for companies
CREATE POLICY "Companies can view own data"
  ON companies
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Companies can update own data"
  ON companies
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Create policies for tasks (everyone can view)
CREATE POLICY "Anyone can view tasks"
  ON tasks
  FOR SELECT
  TO authenticated
  USING (true);

-- Create policies for uploads
CREATE POLICY "Companies can view own uploads"
  ON uploads
  FOR SELECT
  TO authenticated
  USING (company_id = auth.uid());

CREATE POLICY "Companies can create uploads"
  ON uploads
  FOR INSERT
  TO authenticated
  WITH CHECK (company_id = auth.uid());

-- Create policies for daily_calories (everyone can view)
CREATE POLICY "Anyone can view daily calories"
  ON daily_calories
  FOR SELECT
  TO authenticated
  USING (true);

-- Create storage bucket for uploads
INSERT INTO storage.buckets (id, name, public) 
VALUES ('uploads', 'uploads', true)
ON CONFLICT (id) DO NOTHING;

-- Create storage policies
CREATE POLICY "Authenticated users can upload files"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'uploads');

CREATE POLICY "Anyone can view uploaded files"
  ON storage.objects
  FOR SELECT
  TO authenticated
  USING (bucket_id = 'uploads');

-- Create function to update company stats
CREATE OR REPLACE FUNCTION update_company_stats(
  company_id uuid,
  points_to_add integer,
  calories_to_add integer
)
RETURNS void
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE companies 
  SET 
    total_points = total_points + points_to_add,
    total_calories = total_calories + calories_to_add
  WHERE id = company_id;
END;
$$;

-- Sample tasks removed - use admin dashboard to create custom tasks
-- INSERT INTO tasks (title, description, day, target_calories) VALUES
--   ('Morning Yoga', 'Start your day with a 30-minute yoga session. Focus on flexibility and mindfulness.', 1, 150),
--   ('Team Walk', 'Organize a group walk around the office or neighborhood for at least 45 minutes.', 2, 200),
--   ('Stair Challenge', 'Take the stairs instead of elevators. Climb at least 10 flights today.', 3, 100),
--   ('Desk Exercises', 'Perform desk exercises every hour. Include stretches and light cardio.', 4, 120),
--   ('Lunch Break Workout', 'Use your lunch break for a 20-minute high-intensity workout.', 5, 250),
--   ('Active Commute', 'Walk, bike, or jog to work instead of driving or taking public transport.', 6, 300),
--   ('Weekend Adventure', 'Engage in an outdoor activity like hiking, swimming, or cycling for 2+ hours.', 7, 500)
-- ON CONFLICT DO NOTHING;