-- Grant admin-like roles read/write on relevant tables

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'supabase_admin') AND NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'uploads' AND policyname = 'Admins can view uploads'
  ) THEN
    CREATE POLICY "Admins can view uploads"
      ON public.uploads
      FOR SELECT
      TO supabase_admin
      USING (true);
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'supabase_admin') AND NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'uploads' AND policyname = 'Admins can update uploads'
  ) THEN
    CREATE POLICY "Admins can update uploads"
      ON public.uploads
      FOR UPDATE
      TO supabase_admin
      USING (true)
      WITH CHECK (true);
  END IF;
END $$;

DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'supabase_admin') AND NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'companies' AND policyname = 'Admins can view companies'
  ) THEN
    CREATE POLICY "Admins can view companies"
      ON public.companies
      FOR SELECT
      TO supabase_admin
      USING (true);
  END IF;
END $$;

