-- Remove sample tasks to allow custom task uploads
-- This migration removes the pre-inserted sample tasks so admins can create their own

-- Delete all existing sample tasks
DELETE FROM tasks WHERE title IN (
  'Morning Yoga',
  'Team Walk', 
  'Stair Challenge',
  'Desk Exercises',
  'Lunch Break Workout',
  'Active Commute',
  'Weekend Adventure'
);

-- Alternative: Delete all tasks if you want a completely clean slate
-- DELETE FROM tasks;

-- Note: This will remove all sample tasks, allowing you to create custom tasks
-- through the admin dashboard interface or by uploading your own task data
