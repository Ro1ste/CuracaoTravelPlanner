-- Create storage bucket for task documents
INSERT INTO storage.buckets (id, name, public) 
VALUES ('task-documents', 'task-documents', true)
ON CONFLICT (id) DO NOTHING;

-- Create storage policies for task documents
CREATE POLICY "Admins can upload task documents"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'task-documents' AND auth.role() = 'admin');

CREATE POLICY "Admins can update task documents"
  ON storage.objects
  FOR UPDATE
  TO authenticated
  USING (bucket_id = 'task-documents' AND auth.role() = 'admin');

CREATE POLICY "Admins can delete task documents"
  ON storage.objects
  FOR DELETE
  TO authenticated
  USING (bucket_id = 'task-documents' AND auth.role() = 'admin');

CREATE POLICY "Anyone can view task documents"
  ON storage.objects
  FOR SELECT
  TO authenticated
  USING (bucket_id = 'task-documents');
